package com.example.custombrowser

// ============================================================
// 第5段階：デザインの管理（複数保存・切り替え・複製・バックアップ・復元）
// 1つのデザイン = filesDir/designs/<id>/ フォルダ
//   meta.json（名前）, layout.json（配置）, images/（画像）, fonts/（フォント）
// ブックマーク・履歴・設定は、デザインとは別に共通で保存されます。
// ============================================================

import android.content.Context
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class DesignInfo(val id: String, val name: String, val created: Long)

class DesignManager(private val context: Context) {

    private val root = File(context.filesDir, "designs")
    private val prefs = context.getSharedPreferences("designs", Context.MODE_PRIVATE)

    // ZIPの中に入れてよいファイル（これ以外は無視する）
    private val allowed = Regex("""^(meta\.json|layout\.json|images/[^/]+|fonts/[^/]+)$""")

    init {
        root.mkdirs()
        migrateOldData()
        if (list().isEmpty()) {
            val dir = File(root, "default")
            dir.mkdirs()
            writeMeta(dir, "標準のデザイン")
            prefs.edit().putString("active", "default").apply()
        }
    }

    /** 第4段階までのデータ（filesDir直下）を、最初のデザインとして引き継ぐ。 */
    private fun migrateOldData() {
        if (list().isNotEmpty()) return
        val oldLayout = File(context.filesDir, "layout.json")
        val oldImages = File(context.filesDir, "images")
        val oldFonts = File(context.filesDir, "fonts")
        if (!oldLayout.exists() && !oldImages.exists() && !oldFonts.exists()) return
        val dir = File(root, "default")
        dir.mkdirs()
        moveOrCopy(oldLayout, File(dir, "layout.json"))
        moveOrCopy(oldImages, File(dir, "images"))
        moveOrCopy(oldFonts, File(dir, "fonts"))
        writeMeta(dir, "標準のデザイン")
        prefs.edit().putString("active", "default").apply()
    }

    private fun moveOrCopy(src: File, dst: File) {
        if (!src.exists()) return
        if (src.renameTo(dst)) return
        if (src.copyRecursively(dst, true)) src.deleteRecursively()
    }

    // ---------- 一覧・選択 ----------

    fun list(): List<DesignInfo> {
        val dirs = root.listFiles()?.filter { it.isDirectory && !it.name.startsWith("_") } ?: emptyList()
        return dirs.map { d ->
            val m = readMeta(d)
            val name = m?.optString("name", "") ?: ""
            DesignInfo(d.name, if (name.isBlank()) d.name else name, m?.optLong("created", 0L) ?: 0L)
        }.sortedBy { it.created }
    }

    fun activeId(): String {
        val a = prefs.getString("active", null)
        if (a != null && File(root, a).isDirectory) return a
        return list().first().id
    }

    fun setActive(id: String) {
        prefs.edit().putString("active", id).apply()
    }

    fun dir(id: String): File = File(root, id)

    fun activeDir(): File = dir(activeId())

    fun nameOf(id: String): String = list().firstOrNull { it.id == id }?.name ?: id

    // ---------- 作成・複製・名前変更・削除 ----------

    fun create(name: String): String {
        val id = newId()
        val d = dir(id)
        d.mkdirs()
        writeMeta(d, name)
        return id
    }

    fun duplicate(id: String): String? {
        val src = dir(id)
        if (!src.isDirectory) return null
        val newId = newId()
        val dst = dir(newId)
        if (!src.copyRecursively(dst, true)) {
            dst.deleteRecursively()
            return null
        }
        writeMeta(dst, nameOf(id) + "のコピー")
        return newId
    }

    fun rename(id: String, name: String) {
        val d = dir(id)
        if (!d.isDirectory) return
        val created = readMeta(d)?.optLong("created", 0L) ?: System.currentTimeMillis()
        writeMeta(d, name, created)
    }

    /** 使用中のデザインと、最後の1つは削除できない。 */
    fun delete(id: String): Boolean {
        if (id == activeId() || list().size <= 1) return false
        return dir(id).deleteRecursively()
    }

    // ---------- バックアップ・復元（ZIP） ----------

    fun exportTo(ids: List<String>, out: OutputStream) {
        ZipOutputStream(BufferedOutputStream(out)).use { zip ->
            for (id in ids) {
                val d = dir(id)
                if (!d.isDirectory) continue
                for (f in d.walkTopDown().filter { it.isFile }) {
                    val rel = f.relativeTo(d).path.replace(File.separatorChar, '/')
                    if (!allowed.matches(rel)) continue
                    zip.putNextEntry(ZipEntry(id + "/" + rel))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }

    /**
     * ZIPからデザインを復元する。既存のデザインは上書きせず、いつも「新しいデザイン」として追加する。
     * 想定外のファイル名・大きすぎるファイルは取り込まない。取り込めた数を返す。
     */
    fun importFrom(input: InputStream): Int {
        val tmp = File(root, "_import_" + System.currentTimeMillis())
        tmp.mkdirs()
        try {
            var total = 0L
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    val name = e.name.replace('\\', '/')
                    val slash = name.indexOf('/')
                    val ok = !e.isDirectory && slash > 0 && !name.contains("..")
                    if (!ok) {
                        zip.closeEntry()
                        continue
                    }
                    val folder = name.substring(0, slash)
                    val rel = name.substring(slash + 1)
                    if (!folder.matches(Regex("[A-Za-z0-9_-]+")) || !allowed.matches(rel)) {
                        zip.closeEntry()
                        continue
                    }
                    val dest = File(File(tmp, folder), rel)
                    dest.parentFile?.mkdirs()
                    var written = 0L
                    FileOutputStream(dest).use { fos ->
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = zip.read(buf)
                            if (n < 0) break
                            written += n
                            total += n
                            if (written > 30L * 1024 * 1024 || total > 300L * 1024 * 1024) {
                                throw IOException("ファイルが大きすぎます")
                            }
                            fos.write(buf, 0, n)
                        }
                    }
                    zip.closeEntry()
                }
            }
            var count = 0
            val folders = tmp.listFiles()?.filter { it.isDirectory } ?: emptyList()
            for (folder in folders) {
                val layout = File(folder, "layout.json")
                if (!layout.exists()) continue
                val valid = try {
                    JSONObject(layout.readText()).getJSONArray("parts")
                    true
                } catch (e: Exception) {
                    false
                }
                if (!valid) continue
                val name = readMeta(folder)?.optString("name", "") ?: ""
                val newId = newId() + count
                val target = dir(newId)
                if (folder.renameTo(target)) {
                    writeMeta(target, if (name.isBlank()) "復元したデザイン" else name.take(40))
                    count++
                }
            }
            return count
        } finally {
            tmp.deleteRecursively()
        }
    }

    // ---------- 内部 ----------

    private fun newId(): String = "d" + System.currentTimeMillis()

    private fun writeMeta(dir: File, name: String, created: Long = System.currentTimeMillis()) {
        try {
            val o = JSONObject()
            o.put("name", name)
            o.put("created", created)
            File(dir, "meta.json").writeText(o.toString())
        } catch (e: Exception) {
            // 名前を保存できなくても、デザイン自体は使える
        }
    }

    private fun readMeta(dir: File): JSONObject? {
        return try {
            val f = File(dir, "meta.json")
            if (f.exists()) JSONObject(f.readText()) else null
        } catch (e: Exception) {
            null
        }
    }
}
