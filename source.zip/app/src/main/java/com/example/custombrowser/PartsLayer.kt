package com.example.custombrowser

// ============================================================
// パーツを「割合」で配置するための入れ物。
// 画面サイズや向きが変わるたびに、割合から実際の位置を計算し直します。
// ============================================================

import android.content.Context
import android.widget.FrameLayout

class PartsLayer(context: Context) : FrameLayout(context) {

    private fun partW(p: UiPart, w: Int): Int =
        (p.w * w).toInt().coerceIn(1, maxOf(1, w))

    private fun partH(p: UiPart, w: Int, h: Int): Int =
        (p.w * w * p.aspect).toInt().coerceIn(1, maxOf(1, h))

    // 押した瞬間に「押したときの画像」へ切り替えるため、押下状態を遅らせない
    override fun shouldDelayChildPressedState(): Boolean = false

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val p = c.tag as? UiPart ?: continue
            c.measure(
                MeasureSpec.makeMeasureSpec(partW(p, w), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(partH(p, w, h), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val p = c.tag as? UiPart ?: continue
            val cw = partW(p, w)
            val ch = partH(p, w, h)
            val left = (p.x * w).toInt().coerceIn(0, maxOf(0, w - cw))
            val top = (p.y * h).toInt().coerceIn(0, maxOf(0, h - ch))
            c.layout(left, top, left + cw, top + ch)
        }
    }
}
