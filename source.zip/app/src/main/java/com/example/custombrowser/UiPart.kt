package com.example.custombrowser

// ============================================================
// 画面に置く「パーツ」（ボタンやアドレス欄）のデータと、その保存・読み込み。
// 位置とサイズは「画面に対する割合(0.0〜1.0)」で持つので、画面の向きが変わっても対応できます。
// ============================================================

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** パーツに割り当てられる機能の一覧（アプリ側が用意した安全なものだけ） */
enum class PartAction(val label: String) {
    BACK("戻る"),
    FORWARD("進む"),
    RELOAD("再読み込み"),
    HOME("ホーム"),
    NEW_TAB("タブ追加"),
    TAB_LIST("タブ一覧"),
    TAB_COUNT("タブ数"),
    TABS_BACK("ブラウザに戻る"),
    CLOSE_TAB("タブを閉じる"),
    SEARCH_DIALOG("検索入力"),
    EDIT_MODE("編集モード");

    companion object {
        fun fromName(name: String): PartAction? = values().firstOrNull { it.name == name }
    }
}

/**
 * kind: "button"（ボタン）か "address"（アドレス欄）
 * x, y: 左上の位置（画面幅・画面高さに対する割合）
 * w: 幅（画面幅に対する割合）
 * aspect: 高さ ÷ 幅（画像の縦横比を保つために使う）
 * baseAspect: 画像を使っていないときの aspect
 * imageFile: ボタンの画像（アドレス欄では枠の画像）
 * pressedFile: 押している間に表示する画像（ボタンのみ）
 * textInset: アドレス欄の文字の左右の余白（パーツの幅に対する割合）
 * barColor / pushPage: バー（kind="bar"）の色と、「ページをバーの下に配置する」設定
 * textColor / textSize: 文字の色（0=標準）とサイズ（0=標準、単位sp）
 * screen: このパーツが置かれる画面（"browser"=ブラウザ画面 / "tabs"=タブ一覧画面）
 * lockAspect: バー（kind="bar"）の画像の縦横比を固定するか。kind="image" は飾り画像（機能なし・縦横比は常に固定）
 * tabMode ほか: kind="tabarea"（タブ一覧エリア）の設定。並べ方・列の数・サムネイル/タイトル表示・閉じるボタン位置・カードの縦横比
 */
class UiPart(
    val id: String,
    val kind: String,
    var action: String,
    var label: String,
    var x: Float,
    var y: Float,
    var w: Float,
    var aspect: Float,
    var baseAspect: Float,
    var imageFile: String? = null,
    var pressedFile: String? = null,
    var textInset: Float = 0.05f,
    var barColor: Int = 0xFF2B2B2B.toInt(),
    var pushPage: Boolean = true,
    var textColor: Int = 0,
    var textSize: Float = 0f,
    var screen: String = "browser",
    var tabMode: String = "grid",
    var tabColumns: Int = 2,
    var tabThumb: Boolean = true,
    var tabTitle: Boolean = true,
    var tabClose: String = "topright",
    var itemAspect: Float = 1.2f,
    var lockAspect: Boolean = false
)

class LayoutStore(private val context: Context) {

    private val file = File(context.filesDir, "layout.json")
    private val tmpFile = File(context.filesDir, "layout.json.tmp")
    val imageDir = File(context.filesDir, "images").also { it.mkdirs() }

    /** デザイン全体で使うフォント（fonts フォルダ内のファイル名。なければ標準フォント） */
    var fontFile: String? = null
    val fontDir = File(context.filesDir, "fonts").also { it.mkdirs() }

    /** 選んだフォントファイルをアプリ専用の場所にコピーする。使えないファイルなら null。 */
    fun importFont(uri: Uri): String? {
        try {
            val name = "font_" + System.currentTimeMillis() + ".ttf"
            val dest = File(fontDir, name)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dest).use { out -> input.copyTo(out) }
            } ?: return null
            if (dest.length() > 20L * 1024 * 1024) {
                dest.delete()
                return null
            }
            val tf = Typeface.createFromFile(dest)
            if (tf == null || tf === Typeface.DEFAULT) {
                dest.delete()
                return null
            }
            return name
        } catch (e: Exception) {
            return null
        }
    }

    /** 保存済みのレイアウトを読む。なければ（または壊れていたら）初期レイアウト。 */
    fun load(): MutableList<UiPart> {
        try {
            if (file.exists()) {
                val root = JSONObject(file.readText())
                val arr = root.getJSONArray("parts")
                val list = mutableListOf<UiPart>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val img = if (o.has("imageFile") && !o.isNull("imageFile")) o.getString("imageFile") else null
                    list.add(
                        UiPart(
                            o.getString("id"),
                            o.getString("kind"),
                            o.getString("action"),
                            o.getString("label"),
                            o.getDouble("x").toFloat(),
                            o.getDouble("y").toFloat(),
                            o.getDouble("w").toFloat(),
                            o.getDouble("aspect").toFloat(),
                            o.getDouble("baseAspect").toFloat(),
                            img,
                            if (o.has("pressedFile") && !o.isNull("pressedFile")) o.getString("pressedFile") else null,
                            o.optDouble("textInset", 0.05).toFloat(),
                            o.optInt("barColor", 0xFF2B2B2B.toInt()),
                            o.optBoolean("pushPage", true),
                            o.optInt("textColor", 0),
                            o.optDouble("textSize", 0.0).toFloat(),
                            o.optString("screen", "browser"),
                            o.optString("tabMode", "grid"),
                            o.optInt("tabColumns", 2),
                            o.optBoolean("tabThumb", true),
                            o.optBoolean("tabTitle", true),
                            o.optString("tabClose", "topright"),
                            o.optDouble("itemAspect", 1.2).toFloat(),
                            o.optBoolean("lockAspect", false)
                        )
                    )
                }
                // 以前のデザインにはタブ一覧画面がないので、初期のタブ一覧画面を足す
                if (list.none { it.screen == "tabs" }) list.addAll(defaultTabParts())
                fontFile = if (root.has("fontFile") && !root.isNull("fontFile")) root.getString("fontFile") else null
                if (list.isNotEmpty()) return list
            }
        } catch (e: Exception) {
            // 読めなかったら初期レイアウトを使う
        }
        return defaultLayout()
    }

    /** 一度別ファイルに書いてから置き換える（書き込み中に落ちても壊れにくい）。 */
    fun save(parts: List<UiPart>) {
        try {
            val arr = JSONArray()
            for (p in parts) {
                val o = JSONObject()
                o.put("id", p.id)
                o.put("kind", p.kind)
                o.put("action", p.action)
                o.put("label", p.label)
                o.put("x", p.x.toDouble())
                o.put("y", p.y.toDouble())
                o.put("w", p.w.toDouble())
                o.put("aspect", p.aspect.toDouble())
                o.put("baseAspect", p.baseAspect.toDouble())
                o.put("imageFile", p.imageFile ?: JSONObject.NULL)
                o.put("pressedFile", p.pressedFile ?: JSONObject.NULL)
                o.put("textInset", p.textInset.toDouble())
                o.put("barColor", p.barColor)
                o.put("pushPage", p.pushPage)
                o.put("textColor", p.textColor)
                o.put("textSize", p.textSize.toDouble())
                o.put("screen", p.screen)
                o.put("tabMode", p.tabMode)
                o.put("tabColumns", p.tabColumns)
                o.put("tabThumb", p.tabThumb)
                o.put("tabTitle", p.tabTitle)
                o.put("tabClose", p.tabClose)
                o.put("itemAspect", p.itemAspect.toDouble())
                o.put("lockAspect", p.lockAspect)
                arr.put(o)
            }
            val root = JSONObject()
            root.put("version", 1)
            root.put("fontFile", fontFile ?: JSONObject.NULL)
            root.put("parts", arr)
            tmpFile.writeText(root.toString())
            tmpFile.renameTo(file)
        } catch (e: Exception) {
            // 保存に失敗しても、アプリは止めない
        }
    }

    /** 選んだ画像を縮小して、アプリ専用の場所にPNGで保存する。成功したらファイル名を返す。 */
    fun importImage(uri: Uri): String? {
        try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 768 || bounds.outHeight / sample > 768) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val name = "img_" + System.currentTimeMillis() + ".png"
            FileOutputStream(File(imageDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            return name
        } catch (e: Exception) {
            return null
        }
    }

    /** タブ一覧画面の初期配置：背景・タブ一覧エリア・下のバーと3つのボタン */
    fun defaultTabParts(): MutableList<UiPart> {
        val t = "tabs"
        val list = mutableListOf<UiPart>()
        list.add(UiPart("tabbg", "bar", "", "背景", 0.0f, 0.0f, 1.0f, 3.0f, 3.0f, barColor = 0xFF1B1B1B.toInt(), screen = t))
        list.add(
            UiPart(
                "tabarea", "tabarea", "", "タブ一覧", 0.0f, 0.0f, 1.0f, 1.85f, 1.85f,
                barColor = 0xFF2B2B2B.toInt(), screen = t,
                tabMode = "grid", tabColumns = 2, itemAspect = 1.2f
            )
        )
        list.add(UiPart("tabsbar", "bar", "", "バー", 0.0f, 0.92f, 1.0f, 0.10f, 0.10f, screen = t))
        list.add(UiPart("tabsback", "button", "TABS_BACK", "戻る", 0.0f, 0.93f, 0.3f, 0.35f, 0.35f, screen = t))
        list.add(UiPart("tabsnew", "button", "NEW_TAB", "＋タブ", 0.35f, 0.93f, 0.3f, 0.35f, 0.35f, screen = t))
        list.add(UiPart("tabsedit", "button", "EDIT_MODE", "編集", 0.7f, 0.93f, 0.3f, 0.35f, 0.35f, screen = t))
        return list
    }

    fun defaultLayout(): MutableList<UiPart> {
        val list = mutableListOf<UiPart>()
        // バー（ボタンの下に敷く帯）。先に入れるほど下に描かれる
        list.add(UiPart("topbar", "bar", "", "バー", 0.0f, 0.00f, 1.0f, 0.125f, 0.125f))
        list.add(UiPart("bottombar", "bar", "", "バー", 0.0f, 0.94f, 1.0f, 0.10f, 0.10f))
        // 上段：戻る・進む・更新・アドレス欄
        list.add(UiPart("back", "button", "BACK", "◀", 0.00f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("forward", "button", "FORWARD", "▶", 0.12f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("reload", "button", "RELOAD", "↻", 0.24f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("address", "address", "", "アドレス欄", 0.36f, 0.00f, 0.64f, 0.16f, 0.16f))
        // 下段：ホーム・タブ追加・タブ一覧・タブを閉じる・編集
        list.add(UiPart("home", "button", "HOME", "ホーム", 0.0f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("newtab", "button", "NEW_TAB", "＋タブ", 0.2f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("tablist", "button", "TAB_LIST", "タブ一覧", 0.4f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("close", "button", "CLOSE_TAB", "×閉じる", 0.6f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("edit", "button", "EDIT_MODE", "編集", 0.8f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.addAll(defaultTabParts())
        return list
    }
}
