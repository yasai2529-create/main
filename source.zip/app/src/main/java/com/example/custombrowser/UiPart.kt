package com.example.custombrowser

// ============================================================
// 画面に置く「パーツ」（ボタンやアドレス欄）のデータと、その保存・読み込み。
// 位置とサイズは「画面に対する割合(0.0〜1.0)」で持つので、画面の向きが変わっても対応できます。
// ============================================================

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** パーツに割り当てられる機能の一覧（アプリ側が用意した安全なものだけ） */
enum class PartAction(val label: String) {
    BACK("戻る"),
    FORWARD("進む"),
    RELOAD("再読み込み"),
    HOME("ホーム"),
    NEW_TAB("タブ追加"),
    TAB_LIST("タブ一覧"),
    CLOSE_TAB("タブを閉じる"),
    SEARCH_DIALOG("検索入力"),
    EDIT_MODE("編集モード");

    companion object {
        fun fromName(name: String): PartAction? = values().firstOrNull { it.name == name }
    }
}

/**
 * kind: "button"（ボタン）か "address"（アドレス欄）
 * x, y: 左上の位置（画面幅・画面高さに対する割合）
 * w: 幅（画面幅に対する割合）
 * aspect: 高さ ÷ 幅（画像の縦横比を保つために使う）
 * baseAspect: 画像を使っていないときの aspect
 * imageFile: ボタンの画像（アドレス欄では枠の画像）
 * pressedFile: 押している間に表示する画像（ボタンのみ）
 * textInset: アドレス欄の文字の左右の余白（パーツの幅に対する割合）
 */
class UiPart(
    val id: String,
    val kind: String,
    var action: String,
    var label: String,
    var x: Float,
    var y: Float,
    var w: Float,
    var aspect: Float,
    var baseAspect: Float,
    var imageFile: String? = null,
    var pressedFile: String? = null,
    var textInset: Float = 0.05f
)

class LayoutStore(private val context: Context) {

    private val file = File(context.filesDir, "layout.json")
    private val tmpFile = File(context.filesDir, "layout.json.tmp")
    val imageDir = File(context.filesDir, "images").also { it.mkdirs() }

    /** 保存済みのレイアウトを読む。なければ（または壊れていたら）初期レイアウト。 */
    fun load(): MutableList<UiPart> {
        try {
            if (file.exists()) {
                val root = JSONObject(file.readText())
                val arr = root.getJSONArray("parts")
                val list = mutableListOf<UiPart>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val img = if (o.has("imageFile") && !o.isNull("imageFile")) o.getString("imageFile") else null
                    list.add(
                        UiPart(
                            o.getString("id"),
                            o.getString("kind"),
                            o.getString("action"),
                            o.getString("label"),
                            o.getDouble("x").toFloat(),
                            o.getDouble("y").toFloat(),
                            o.getDouble("w").toFloat(),
                            o.getDouble("aspect").toFloat(),
                            o.getDouble("baseAspect").toFloat(),
                            img,
                            if (o.has("pressedFile") && !o.isNull("pressedFile")) o.getString("pressedFile") else null,
                            o.optDouble("textInset", 0.05).toFloat()
                        )
                    )
                }
                if (list.isNotEmpty()) return list
            }
        } catch (e: Exception) {
            // 読めなかったら初期レイアウトを使う
        }
        return defaultLayout()
    }

    /** 一度別ファイルに書いてから置き換える（書き込み中に落ちても壊れにくい）。 */
    fun save(parts: List<UiPart>) {
        try {
            val arr = JSONArray()
            for (p in parts) {
                val o = JSONObject()
                o.put("id", p.id)
                o.put("kind", p.kind)
                o.put("action", p.action)
                o.put("label", p.label)
                o.put("x", p.x.toDouble())
                o.put("y", p.y.toDouble())
                o.put("w", p.w.toDouble())
                o.put("aspect", p.aspect.toDouble())
                o.put("baseAspect", p.baseAspect.toDouble())
                o.put("imageFile", p.imageFile ?: JSONObject.NULL)
                o.put("pressedFile", p.pressedFile ?: JSONObject.NULL)
                o.put("textInset", p.textInset.toDouble())
                arr.put(o)
            }
            val root = JSONObject()
            root.put("version", 1)
            root.put("parts", arr)
            tmpFile.writeText(root.toString())
            tmpFile.renameTo(file)
        } catch (e: Exception) {
            // 保存に失敗しても、アプリは止めない
        }
    }

    /** 選んだ画像を縮小して、アプリ専用の場所にPNGで保存する。成功したらファイル名を返す。 */
    fun importImage(uri: Uri): String? {
        try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 768 || bounds.outHeight / sample > 768) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val name = "img_" + System.currentTimeMillis() + ".png"
            FileOutputStream(File(imageDir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            return name
        } catch (e: Exception) {
            return null
        }
    }

    fun defaultLayout(): MutableList<UiPart> {
        val list = mutableListOf<UiPart>()
        // 上段：戻る・進む・更新・アドレス欄
        list.add(UiPart("back", "button", "BACK", "◀", 0.00f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("forward", "button", "FORWARD", "▶", 0.12f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("reload", "button", "RELOAD", "↻", 0.24f, 0.00f, 0.12f, 1.0f, 1.0f))
        list.add(UiPart("address", "address", "", "アドレス欄", 0.36f, 0.00f, 0.64f, 0.16f, 0.16f))
        // 下段：ホーム・タブ追加・タブ一覧・タブを閉じる・編集
        list.add(UiPart("home", "button", "HOME", "ホーム", 0.0f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("newtab", "button", "NEW_TAB", "＋タブ", 0.2f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("tablist", "button", "TAB_LIST", "タブ一覧", 0.4f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("close", "button", "CLOSE_TAB", "×閉じる", 0.6f, 0.94f, 0.2f, 0.5f, 0.5f))
        list.add(UiPart("edit", "button", "EDIT_MODE", "編集", 0.8f, 0.94f, 0.2f, 0.5f, 0.5f))
        return list
    }
}
