package com.example.custombrowser

// ============================================================
// ブックマーク・履歴・設定・ページ内検索などの「小さな画面（ダイアログ）」。
// どのボタンやメニュー項目からでも、同じものが開きます。
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast

class BrowserDialogs(
    private val activity: Activity,
    private val core: BrowserCore,
    private val openUrl: (String) -> Unit
) {

    private fun toast(msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    private fun confirm(title: String, message: String, onYes: () -> Unit) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("はい") { _, _ -> onYes() }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    /** 一覧に出す文字：題名と、短くしたURL（長いURLが並んで見づらくならないように）。 */
    private fun itemText(e: Entry): String {
        val shortUrl = shorten(e.url)
        val title = if (e.title.isBlank()) shortUrl else e.title
        return cut(title, 40) + "\n" + shortUrl
    }

    /** https:// や www. を省き、長ければ「…」で省略する。 */
    private fun shorten(url: String): String {
        var s = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        if (s.endsWith("/")) s = s.dropLast(1)
        return cut(s, 38)
    }

    private fun cut(s: String, max: Int): String =
        if (s.length > max) s.substring(0, max) + "…" else s

    // ---------- ブックマーク ----------

    fun addCurrentBookmark() {
        val t = core.currentTab
        if (t == null || t.url.isBlank()) {
            toast("追加できるページがありません")
            return
        }
        val added = core.data.addBookmark(if (t.title.isBlank()) t.url else t.title, t.url)
        toast(if (added) "ブックマークに追加しました" else "すでに追加済みです")
    }

    fun showBookmarks() {
        val list = core.data.bookmarks
        if (list.isEmpty()) {
            toast("ブックマークはまだありません")
            return
        }
        val items = list.map { itemText(it) }.toTypedArray()
        val d = AlertDialog.Builder(activity)
            .setTitle("ブックマーク（長押しで削除）")
            .setItems(items) { _, which -> openUrl(list[which].url) }
            .setNegativeButton("閉じる", null)
            .show()
        d.listView.setOnItemLongClickListener { _, _, pos, _ ->
            confirm("削除", "このブックマークを削除しますか？") {
                core.data.removeBookmark(pos)
                d.dismiss()
                showBookmarks()
            }
            true
        }
    }

    // ---------- 履歴 ----------

    fun showHistory() {
        val list = core.data.history
        if (list.isEmpty()) {
            toast("履歴はまだありません")
            return
        }
        val items = list.map { itemText(it) }.toTypedArray()
        val d = AlertDialog.Builder(activity)
            .setTitle("閲覧履歴（長押しで削除）")
            .setItems(items) { _, which -> openUrl(list[which].url) }
            .setNeutralButton("全て削除") { _, _ ->
                confirm("履歴を全て削除", "閲覧履歴をすべて削除しますか？") {
                    core.data.clearHistory()
                    toast("履歴を削除しました")
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
        d.listView.setOnItemLongClickListener { _, _, pos, _ ->
            core.data.removeHistory(pos)
            d.dismiss()
            showHistory()
            true
        }
    }

    // ---------- ダウンロード ----------

    /** ダウンロードしたファイルの一覧は、端末のダウンロード画面で見られる。 */
    fun openDownloads() {
        try {
            activity.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            toast("ダウンロード画面を開けませんでした")
        }
    }

    // ---------- ページ内検索 ----------

    fun showFind() {
        val input = EditText(activity)
        input.isSingleLine = true
        input.hint = "ページ内を検索"
        val d = AlertDialog.Builder(activity)
            .setTitle("ページ内検索")
            .setView(input)
            .setPositiveButton("次へ", null)
            .setNeutralButton("前へ", null)
            .setNegativeButton("閉じる", null)
            .create()
        d.setOnDismissListener { core.clearFind() }
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
        var last = ""
        // ボタンを押しても閉じないよう、あとから動作を設定する
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val q = input.text.toString()
            if (q.isNotEmpty()) {
                if (q != last) {
                    core.find(q)
                    last = q
                } else {
                    core.findNext(true)
                }
            }
        }
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val q = input.text.toString()
            if (q.isNotEmpty()) {
                if (q != last) {
                    core.find(q)
                    last = q
                } else {
                    core.findNext(false)
                }
            }
        }
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener { d.dismiss() }
    }

    // ---------- 設定 ----------

    fun togglePrivate() {
        val on = !core.data.privateMode
        core.setPrivate(on)
        toast(if (on) "プライベートブラウジング：ON（履歴とキャッシュを残しません）" else "プライベートブラウジング：OFF")
    }

    fun showSettings() {
        val data = core.data
        val items = arrayOf(
            "ホームページ：" + data.homeUrl,
            "文字サイズ：" + data.textZoom + "%",
            "プライベートブラウジング：" + (if (data.privateMode) "ON" else "OFF") + "（タップで切替）",
            "Cookieを削除（ログインが外れます）",
            "キャッシュを削除",
            "閲覧履歴を削除",
            "PCサイトで表示：" + (if (data.desktopMode) "ON" else "OFF") + "（タップで切替）"
        )
        AlertDialog.Builder(activity)
            .setTitle("設定")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askHome()
                    1 -> askZoom()
                    2 -> togglePrivate()
                    3 -> confirm("Cookieを削除", "ログイン中のサービスはすべてログアウトされます。よろしいですか？") {
                        core.clearCookies()
                        toast("Cookieを削除しました")
                    }
                    4 -> {
                        core.clearCache()
                        toast("キャッシュを削除しました")
                    }
                    5 -> confirm("履歴を削除", "閲覧履歴をすべて削除しますか？") {
                        core.data.clearHistory()
                        toast("履歴を削除しました")
                    }
                    else -> {
                        data.desktopMode = !data.desktopMode
                        core.applySettings()
                        core.reload()
                        toast(if (data.desktopMode) "PCサイトで表示します" else "スマホ向けの表示に戻しました")
                    }
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun askHome() {
        val input = EditText(activity)
        input.isSingleLine = true
        input.setText(core.data.homeUrl)
        AlertDialog.Builder(activity)
            .setTitle("ホームページ")
            .setView(input)
            .setPositiveButton("保存") { _, _ ->
                var u = input.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u
                    core.data.homeUrl = u
                    toast("ホームページを保存しました")
                }
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun askZoom() {
        val labels = arrayOf("80%", "100%（標準）", "120%", "150%", "200%")
        val values = intArrayOf(80, 100, 120, 150, 200)
        AlertDialog.Builder(activity)
            .setTitle("文字サイズ")
            .setItems(labels) { _, which ->
                core.data.textZoom = values[which]
                core.applySettings()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }
}
