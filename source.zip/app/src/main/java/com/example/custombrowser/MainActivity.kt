package com.example.custombrowser

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {

    private lateinit var core: BrowserCore
    private lateinit var ui: BrowserUi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        core = BrowserCore(this)
        ui = BrowserUi(this, core)
        core.listener = ui
        setContentView(ui.root)
        core.newTab()
    }

    override fun onDestroy() {
        // プライベート中のまま閉じたときは、キャッシュを消す
        if (core.data.privateMode) core.clearCache()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (ui.onBack()) return
        val wv = core.currentTab?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == BrowserUi.REQ_IMAGE) {
            data?.data?.let { ui.onImagePicked(it) }
        } else if (requestCode == BrowserUi.REQ_FONT) {
            data?.data?.let { ui.onFontPicked(it) }
        }
    }
}
