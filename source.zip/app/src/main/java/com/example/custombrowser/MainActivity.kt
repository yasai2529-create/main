package com.example.custombrowser

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private lateinit var core: BrowserCore
    private lateinit var ui: BrowserUi
    private var started = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null // サイトからのアップロード要求

    companion object {
        const val REQ_FILE = 1100
    }

    private fun crashFile() = File(filesDir, "last_crash.txt")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 異常終了したときに、原因の記録を残す（次の起動で画面に表示する）
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                crashFile().writeText(e.stackTraceToString().take(6000))
            } catch (x: Throwable) {
                // 記録に失敗しても、そのまま終了する
            }
            previous?.uncaughtException(t, e)
        }

        val log = if (crashFile().exists()) crashFile().readText() else null
        if (log != null) showSafeScreen(log) else startNormally()
    }

    private fun startNormally() {
        try {
            core = BrowserCore(this)
            core.fileChooserHandler = { callback, params ->
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
            ui = BrowserUi(this, core)
            core.listener = ui
            setContentView(ui.root)
            core.newTab()
            started = true
        } catch (e: Throwable) {
            started = false
            showSafeScreen(e.stackTraceToString().take(6000))
        }
    }

    /** 前回の異常終了の記録を見せる画面。ここから、そのまま起動／デザインを初期化して起動ができる。 */
    private fun showSafeScreen(log: String) {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "前回、アプリが異常終了しました"
        title.textSize = 18f
        title.setTextColor(Color.BLACK)
        col.addView(title)

        val note = TextView(this)
        note.text = "下の記録をスクリーンショットして、Claudeに送ってください（原因の特定に使います）。\n"
        note.textSize = 13f
        col.addView(note)

        col.addView(button("そのまま起動してみる") {
            crashFile().delete()
            startNormally()
        })
        col.addView(button("デザインを初期状態にして起動") {
            resetActiveDesign()
            crashFile().delete()
            startNormally()
        })

        val tv = TextView(this)
        tv.text = log
        tv.textSize = 10f
        tv.setTextColor(Color.DKGRAY)
        tv.setTextIsSelectable(true)
        col.addView(tv)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    /** 今のデザインの配置ファイルを、バックアップ名に変えて退避する（次の起動で初期配置になる）。 */
    private fun resetActiveDesign() {
        try {
            val dir = DesignManager(this).activeDir()
            val f = File(dir, "layout.json")
            if (f.exists()) f.renameTo(File(dir, "layout.json.bak"))
        } catch (e: Throwable) {
            // 退避できなくても、起動は試みる
        }
    }

    override fun onDestroy() {
        // プライベート中のまま閉じたときは、キャッシュを消す
        if (started && core.data.privateMode) core.clearCache()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!started) {
            super.onBackPressed()
            return
        }
        if (ui.onBack()) return
        val wv = core.currentTab?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            // キャンセルされたときも、必ずサイトに結果を返す（返さないと、サイトの画面が固まる）
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            return
        }
        if (!started || resultCode != RESULT_OK) return
        if (requestCode == BrowserUi.REQ_IMAGE) {
            data?.data?.let { ui.onImagePicked(it) }
        } else if (requestCode == BrowserUi.REQ_FONT) {
            data?.data?.let { ui.onFontPicked(it) }
        } else if (requestCode == BrowserUi.REQ_EXPORT) {
            data?.data?.let { ui.onExportUri(it) }
        } else if (requestCode == BrowserUi.REQ_IMPORT) {
            data?.data?.let { ui.onImportUri(it) }
        }
    }
}
