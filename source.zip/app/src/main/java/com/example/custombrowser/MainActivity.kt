package com.example.custombrowser

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {

    private lateinit var core: BrowserCore
    private lateinit var ui: BrowserUi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        core = BrowserCore(this)
        ui = BrowserUi(this, core)
        core.listener = ui
        setContentView(ui.root)
        core.newTab()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (ui.onBack()) return
        val wv = core.currentTab?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == BrowserUi.REQ_IMAGE && resultCode == RESULT_OK) {
            data?.data?.let { ui.onImagePicked(it) }
        }
    }
}
