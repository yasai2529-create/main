package com.example.custombrowser

import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {

    private lateinit var core: BrowserCore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        core = BrowserCore(this)
        val ui = BrowserUi(this, core)
        core.listener = ui
        setContentView(ui.root)
        core.newTab()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val wv = core.currentTab?.webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
