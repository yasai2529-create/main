package com.example.custombrowser

// ============================================================
// 見た目を担当。パーツ（UiPart）の一覧から画面を組み立てます。
// 通常モード：パーツを押すと機能が動く
// 編集モード：パーツをドラッグ・選択して、大きさ・画像・機能を変える
// ブラウザの機能は BrowserCore を呼ぶだけです。
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.view.WindowInsets
import android.webkit.WebChromeClient
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class BrowserUi(
    private val activity: Activity,
    private val core: BrowserCore
) : BrowserListener {

    companion object {
        const val REQ_IMAGE = 1001
        const val REQ_FONT = 1002
        const val REQ_EXPORT = 1003
        const val REQ_IMPORT = 1004

        val COLOR_NAMES = arrayOf(
            "ダークグレー", "黒", "白", "ライトグレー", "青", "水色",
            "赤", "ピンク", "緑", "黄", "茶", "透明"
        )
        val COLOR_VALUES = intArrayOf(
            0xFF2B2B2B.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFE0E0E0.toInt(),
            0xFF1E5BD8.toInt(), 0xFF4FC3F7.toInt(), 0xFFD32F2F.toInt(), 0xFFF48FB1.toInt(),
            0xFF2E7D32.toInt(), 0xFFFFEB3B.toInt(), 0xFF5D4037.toInt(), 0x00000000
        )
    }

    val root = FrameLayout(activity)
    private val webContainer = FrameLayout(activity)
    private val layer = PartsLayer(activity)
    private val panel = LinearLayout(activity)
    private val panelTitle = TextView(activity)

    private val designs = DesignManager(activity)
    private var store = LayoutStore(activity, designs.activeDir())
    private var parts: MutableList<UiPart> = store.load()
    private val views = HashMap<String, View>()
    private val addressBars = mutableListOf<EditText>()
    private val marqueeOverlays = HashMap<String, TextView>() // 流れる文字を表示する、アドレス欄の上の重ね表示
    private var addressUrl = ""

    private var editMode = false
    private var selectedId: String? = null
    private var pendingImagePartId: String? = null
    private var pendingPressed = false
    private var panelOnTop = false
    private var customView: View? = null // 動画の全画面表示中の画面
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var currentScreen = "browser"
    private var pendingExportIds: List<String> = emptyList()
    private val designDialogs = DesignDialogs(
        activity, designs,
        { store.save(parts) },
        { id -> switchDesign(id) },
        { ids, fileName -> startExport(ids, fileName) },
        { startImport() }
    )
    private val findBar = FindBar(activity, core) { root.post { updateWebInsets() } }
    private val dialogs = BrowserDialogs(activity, core) { url ->
        core.loadUrl(url)
        if (currentScreen != "browser") showBrowserScreen()
    }
    private var typeface: Typeface? = null
    private var lastInsetTop = -1
    private var lastInsetBottom = -1

    init {
        root.addView(
            webContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            layer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            findBar.view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, findBar.heightPx, Gravity.TOP)
        )
        buildPanel()
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        panel.visibility = View.GONE
        core.customViewShow = { v, cb -> showCustomView(v, cb) }
        core.customViewHide = { hideCustomView() }
        rebuildParts()
        applyFindBarColors()
        // 画面サイズ・向きが変わったら、バーに合わせてページの位置を調整し直す
        // 画面の「大きさ」が実際に変わったときだけ処理する（毎回の再配置で動かすと、タブ一覧が作り直され続けてしまう）
        layer.addOnLayoutChangeListener { _, l, t, r, b, oldL, oldT, oldR, oldB ->
            val sizeChanged = (r - l) != (oldR - oldL) || (b - t) != (oldB - oldT)
            if (sizeChanged) {
                root.post {
                    updateWebInsets()
                    if (currentScreen == "tabs") rebuildTabAreas()
                }
            }
        }
    }

    // ---------- BrowserListener ----------

    override fun onTabChanged() {
        if (findBar.visible) findBar.hide()
        webContainer.removeAllViews()
        updateTabCounts()
        if (currentScreen == "tabs") rebuildTabAreas()
        val tab = core.currentTab ?: return
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setAddressText(tab.url)
    }

    override fun onPageInfo(tab: Tab) {
        if (tab == core.currentTab) setAddressText(tab.url)
    }

    private fun setAddressText(url: String) {
        addressUrl = url
        for (e in addressBars) {
            if (e.hasFocus()) continue // 入力中は書き換えない
            val pid = (e.tag as? UiPart)?.id
            // 流す設定のアドレス欄は、入力欄を空にして、上に重ねた流れる文字で表示する
            if (pid != null && marqueeOverlays.containsKey(pid)) e.setText("") else e.setText(url)
        }
        for (m in marqueeOverlays.values) updateOverlay(m)
    }

    // ---------- パーツの作成 ----------

    private fun rebuildParts() {
        typeface = store.fontFile?.let { loadTypeface(it) }
        layer.removeAllViews()
        views.clear()
        addressBars.clear()
        marqueeOverlays.clear()
        for (p in parts) {
            if (p.screen != currentScreen) continue
            val v = createView(p)
            v.tag = p
            views[p.id] = v
            layer.addView(v)
            marqueeOverlays[p.id]?.let {
                it.tag = p
                layer.addView(it)
            }
        }
        refreshSelection()
        updateTabCounts()
        setAddressText(core.currentTab?.url ?: addressUrl)
        root.post { updateWebInsets() }
    }

    private fun createView(p: UiPart): View {
        val v: View
        if (p.kind == "address") {
            val e = EditText(activity)
            e.isSingleLine = true
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            e.imeOptions = EditorInfo.IME_ACTION_GO
            e.hint = "URLまたは検索ワード"
            e.textSize = 14f
            val bgBmp = loadBitmap(p.imageFile)
            if (bgBmp != null) {
                e.background = BitmapDrawable(activity.resources, bgBmp)
            } else {
                val bg = GradientDrawable()
                bg.setColor(Color.WHITE)
                bg.setStroke(2, Color.GRAY)
                bg.cornerRadius = 16f
                e.background = bg
            }
            e.gravity = Gravity.CENTER_VERTICAL
            val inset = (activity.resources.displayMetrics.widthPixels * p.w * p.textInset).toInt()
            e.setPadding(maxOf(inset, 16), 0, maxOf(inset, 16), 0)
            e.setOnEditorActionListener { tv, _, _ ->
                core.openInput(tv.text.toString())
                hideKeyboard(tv)
                true
            }
            applyTextStyle(e, p, 14f)
            setupMarquee(e, p)
            addressBars.add(e)
            v = e
        } else if (p.kind == "tabarea") {
            val area = TabAreaView(activity)
            area.blockChildren = editMode
            fillTabArea(p, area)
            v = area
        } else if (p.kind == "bar" || p.kind == "image") {
            val bmp = loadBitmap(p.imageFile)
            if (bmp != null) {
                // 画像は輪郭に沿ってタップ判定される（透明な部分は下のパーツやページに届く）
                val iv = ShapedImageView(activity)
                iv.setImages(bmp, null)
                applyAnimation(iv, p.imageFile)
                iv.isClickable = p.kind == "bar" || p.action.isNotEmpty() // バーは下のページを触ってしまわないよう受け止める
                if (p.action.isNotEmpty()) iv.setOnClickListener { runAction(p) }
                v = iv
            } else {
                val bv = View(activity)
                if (p.kind == "bar") {
                    bv.setBackgroundColor(p.barColor)
                    bv.isClickable = true
                    if (p.action.isNotEmpty()) bv.setOnClickListener { runAction(p) }
                } else {
                    // 画像が未設定の飾り画像：点線の枠を表示
                    val ph = GradientDrawable()
                    ph.setColor(Color.argb(40, 128, 128, 128))
                    ph.setStroke(4, Color.GRAY, 16f, 10f)
                    bv.background = ph
                }
                v = bv
            }
        } else {
            val bmp = loadBitmap(p.imageFile)
            if (bmp != null) {
                val iv = ShapedImageView(activity)
                iv.setImages(bmp, loadBitmap(p.pressedFile))
                applyAnimation(iv, p.imageFile)
                applyOverlayStyle(iv, p)
                iv.setOnClickListener { runAction(p) }
                v = iv
            } else {
                val b = Button(activity)
                b.text = p.label
                b.textSize = 12f
                b.isAllCaps = false
                b.setPadding(0, 0, 0, 0)
                b.minWidth = 0
                b.minimumWidth = 0
                b.minHeight = 0
                b.minimumHeight = 0
                applyTextStyle(b, p, 12f)
                b.setOnClickListener { runAction(p) }
                v = b
            }
        }
        attachTouch(v, p)
        return v
    }

    /** 編集モードのときだけ、ドラッグ移動と選択を行う。通常モードでは何もしない。 */
    private fun attachTouch(v: View, p: UiPart) {
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        v.setOnTouchListener { _, e ->
            if (!editMode) {
                false
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        select(p)
                        downX = e.rawX
                        downY = e.rawY
                        startX = p.x
                        startY = p.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val lw = layer.width.toFloat()
                        val lh = layer.height.toFloat()
                        if (lw > 0f && lh > 0f) {
                            p.x = (startX + (e.rawX - downX) / lw).coerceIn(0f, maxOf(0f, 1f - p.w))
                            p.y = (startY + (e.rawY - downY) / lh).coerceIn(0f, maxOf(0f, 1f - heightFrac(p)))
                            layer.requestLayout()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        store.save(parts)
                        updateWebInsets()
                        updatePanel()
                    }
                }
                true
            }
        }
    }

    private fun loadBitmap(name: String?): Bitmap? {
        if (name == null) return null
        val f = File(store.imageDir, name)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun heightFrac(p: UiPart): Float {
        val lw = layer.width.toFloat()
        val lh = layer.height.toFloat()
        return if (lh <= 0f) 0f else p.w * lw * p.aspect / lh
    }

    // ---------- 機能の実行 ----------

    private fun runAction(p: UiPart) {
        val a = PartAction.fromName(p.action)
        // メニュー画面から機能を実行するときは、先にメニューを閉じてから実行する
        // （あとで閉じると、そのとき開いたばかりの検索バーなどまで閉じてしまうため）
        if (currentScreen == "menu" && a != null && a != PartAction.EDIT_MODE && a != PartAction.MENU) {
            showBrowserScreen()
        }
        performAction(a)
    }

    private fun performAction(a: PartAction?) {
        when (a) {
            PartAction.BACK -> core.goBack()
            PartAction.FORWARD -> core.goForward()
            PartAction.RELOAD -> core.reload()
            PartAction.HOME -> core.goHome()
            PartAction.NEW_TAB -> {
                core.newTab()
                if (currentScreen == "tabs") showBrowserScreen()
            }
            PartAction.TAB_LIST -> showTabsScreen()
            PartAction.TAB_COUNT -> showTabsScreen()
            PartAction.TABS_BACK -> showBrowserScreen()
            PartAction.ADD_BOOKMARK -> dialogs.addCurrentBookmark()
            PartAction.BOOKMARKS -> dialogs.showBookmarks()
            PartAction.HISTORY -> dialogs.showHistory()
            PartAction.DOWNLOADS -> dialogs.openDownloads()
            PartAction.FIND -> findBar.show()
            PartAction.SETTINGS -> dialogs.showSettings()
            PartAction.PRIVATE_TOGGLE -> dialogs.togglePrivate()
            PartAction.DESIGNS -> designDialogs.show()
            PartAction.MENU -> setScreen("menu")
            PartAction.MENU_CLOSE -> showBrowserScreen()
            PartAction.CLOSE_TAB -> core.closeCurrentTab()
            PartAction.SEARCH_DIALOG -> showSearchDialog()
            PartAction.EDIT_MODE -> setEditMode(true)
            null -> {}
        }
    }

    private fun showTabList() {
        val titles = core.tabs.mapIndexed { i, t ->
            (if (i == core.currentIndex) "● " else "") + t.title
        }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("タブ一覧")
            .setItems(titles) { _, which -> core.switchTo(which) }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showSearchDialog() {
        val input = EditText(activity)
        input.isSingleLine = true
        AlertDialog.Builder(activity)
            .setTitle("URLまたは検索ワード")
            .setView(input)
            .setPositiveButton("開く") { _, _ -> core.openInput(input.text.toString()) }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun hideKeyboard(v: View) {
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun toast(msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- 編集モード ----------

    fun onBack(): Boolean {
        if (customView != null) {
            hideCustomView()
            return true
        }
        if (findBar.visible) {
            findBar.hide()
            return true
        }
        if (editMode) {
            setEditMode(false)
            return true
        }
        if (currentScreen != "browser") {
            showBrowserScreen()
            return true
        }
        return false
    }

    private fun setEditMode(on: Boolean) {
        editMode = on
        selectedId = null
        if (!on) store.save(parts)
        panel.visibility = if (on) View.VISIBLE else View.GONE
        if (on) toast("パネルに隠れたパーツは「▲▼移動」で上下に動かして編集できます")
        refreshSelection()
        updatePanel()
    }

    private fun selectedPart(): UiPart? = parts.firstOrNull { it.id == selectedId }

    private fun select(p: UiPart) {
        selectedId = p.id
        refreshSelection()
        updatePanel()
    }

    /** 編集中は枠線を表示。選択中のパーツは赤い太枠。 */
    private fun refreshSelection() {
        for (m in marqueeOverlays.values) m.isClickable = !editMode // 編集中は、下の入力欄をドラッグできるようにする
        for (p in parts) {
            val v = views[p.id] ?: continue
            if (v is TabAreaView) v.blockChildren = editMode
            if (!editMode) {
                v.foreground = null
            } else {
                val d = GradientDrawable()
                d.setColor(Color.TRANSPARENT)
                if (p.id == selectedId) d.setStroke(6, Color.RED) else d.setStroke(2, Color.GRAY)
                v.foreground = d
            }
        }
    }

    private fun updatePanel() {
        val sel = selectedPart()
        panelTitle.text = if (sel == null) {
            "編集モード：パーツをタップして選択"
        } else if (sel.kind == "address") {
            "選択中：アドレス欄"
        } else if (sel.kind == "bar") {
            "選択中：バー"
        } else if (sel.kind == "tabarea") {
            "選択中：タブ一覧エリア"
        } else if (sel.kind == "image") {
            "選択中：飾り画像"
        } else {
            "選択中：" + sel.label + "（" + (PartAction.fromName(sel.action)?.label ?: "") + "）"
        }
        val screenName = when (currentScreen) {
            "tabs" -> "[タブ一覧画面] "
            "menu" -> "[メニュー画面] "
            else -> "[ブラウザ画面] "
        }
        panelTitle.text = screenName + panelTitle.text
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (panelOnTop) Gravity.TOP else Gravity.BOTTOM
        panel.layoutParams = lp
    }

    private fun buildPanel() {
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.argb(235, 40, 40, 40))
        panel.setPadding(8, 8, 8, 8)
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.textSize = 13f
        val header = LinearLayout(activity)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(panelTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(panelButton("画面切替") { setScreen(when (currentScreen) { "browser" -> "tabs"; "tabs" -> "menu"; else -> "browser" }) })
        header.addView(panelButton("▲▼移動") { togglePanelSide() })
        panel.addView(header)

        val row1 = LinearLayout(activity)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(panelButton("＋追加") { addPart() }, weightParams())
        row1.addView(panelButton("画像") { pickImage(false) }, weightParams())
        row1.addView(panelButton("画像戻す") { clearImage() }, weightParams())
        row1.addView(panelButton("機能") { changeAction() }, weightParams())
        row1.addView(panelButton("削除") { deletePart() }, weightParams())

        val row2 = LinearLayout(activity)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(panelButton("小さく") { resizePart(0.87f) }, weightParams())
        row2.addView(panelButton("大きく") { resizePart(1.15f) }, weightParams())
        row2.addView(panelButton("高く") { heightPart(1.15f) }, weightParams())
        row2.addView(panelButton("低く") { heightPart(0.87f) }, weightParams())
        row2.addView(panelButton("初期化") { confirmReset() }, weightParams())
        row2.addView(panelButton("完了") { setEditMode(false) }, weightParams())

        val row3 = LinearLayout(activity)
        row3.orientation = LinearLayout.HORIZONTAL
        row3.addView(panelButton("押下画像") { pickImage(true) }, weightParams())
        row3.addView(panelButton("押下戻す") { clearPressed() }, weightParams())
        row3.addView(panelButton("余白") { changeInset() }, weightParams())
        row3.addView(panelButton("詳細") { showDetailMenu() }, weightParams())

        panel.addView(row1)
        panel.addView(row2)
        panel.addView(row3)
    }

    /** 操作パネルを画面の上側／下側に動かす（隠れているパーツを編集するため）。 */
    private fun togglePanelSide() {
        panelOnTop = !panelOnTop
        updatePanel()
    }

    private fun panelButton(label: String, onClick: () -> Unit): Button {
        val b = Button(activity)
        b.text = label
        b.textSize = 11f
        b.isAllCaps = false
        b.setPadding(0, 0, 0, 0)
        b.minWidth = 0
        b.minimumWidth = 0
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    // ---------- 編集の操作 ----------

    private fun newId(): String = java.util.UUID.randomUUID().toString().take(8)

    private fun addPart() {
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = (listOf("アドレス欄", "バー（帯）", "タブ一覧エリア", "飾り画像（機能なし）") + actions.map { it.label }).toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("追加するパーツ")
            .setItems(items) { _, which ->
                val p = if (which == 0) {
                    UiPart(newId(), "address", "", "アドレス欄", 0.25f, 0.4f, 0.5f, 0.16f, 0.16f)
                } else if (which == 1) {
                    UiPart(newId(), "bar", "", "バー", 0.0f, 0.4f, 1.0f, 0.12f, 0.12f)
                } else if (which == 2) {
                    UiPart(
                        newId(), "tabarea", "", "タブ一覧", 0.0f, 0.1f, 1.0f, 1.2f, 1.2f,
                        barColor = 0xFF2B2B2B.toInt(), tabMode = "grid", tabColumns = 2, itemAspect = 1.2f
                    )
                } else if (which == 3) {
                    UiPart(newId(), "image", "", "画像", 0.3f, 0.3f, 0.3f, 1.0f, 1.0f)
                } else {
                    val a = actions[which - 4]
                    UiPart(newId(), "button", a.name, a.label, 0.4f, 0.4f, 0.2f, 0.5f, 0.5f)
                }
                // バーは他のパーツの下に敷くので、先頭に入れる
                p.screen = currentScreen
                if (p.kind == "image") root.post { pickImage(false) } // 追加したらすぐ画像を選ばせる
                if (p.kind == "tabarea" && currentScreen != "tabs") {
                    toast("タブ一覧エリアは、タブ一覧画面で追加してください（「画面切替」で移動できます）")
                } else if (p.kind == "bar") {
                    val at = parts.indexOfFirst { it.screen == currentScreen && it.kind != "bar" }
                    if (at >= 0) parts.add(at, p) else parts.add(p)
                } else {
                    parts.add(p)
                }
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun pickImage(pressed: Boolean) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (p.kind == "tabarea") {
            toast("タブ一覧エリアには画像を設定できません（背景はバーで作れます）")
            return
        }
        if (pressed) {
            if (p.kind == "address" || p.kind == "image" || p.kind == "bar") {
                toast("押したときの画像はボタン専用です")
                return
            }
            if (p.imageFile == null) {
                toast("先に通常の画像を設定してください")
                return
            }
        }
        pendingImagePartId = p.id
        pendingPressed = pressed
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_IMAGE)
    }

    /** 画像が選ばれたあと、MainActivity から呼ばれる。 */
    fun onImagePicked(uri: Uri) {
        val id = pendingImagePartId ?: return
        val p = parts.firstOrNull { it.id == id } ?: return
        val name = store.importImage(uri)
        if (name == null) {
            toast("画像を読み込めませんでした")
            return
        }
        val bmp = BitmapFactory.decodeFile(File(store.imageDir, name).path)
        if (bmp == null) {
            toast("画像を読み込めませんでした")
            return
        }
        if (pendingPressed) {
            bmp.recycle()
            val old = p.pressedFile
            p.pressedFile = name
            deleteIfUnused(old)
        } else {
            if (p.kind != "bar" || p.lockAspect) p.aspect = bmp.height.toFloat() / bmp.width.toFloat()
            bmp.recycle()
            val old = p.imageFile
            p.imageFile = name
            deleteIfUnused(old)
        }
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun clearImage() {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        val oldA = p.imageFile
        val oldB = p.pressedFile
        p.imageFile = null
        p.pressedFile = null
        p.lockAspect = false
        if (p.kind != "bar") p.aspect = p.baseAspect
        deleteIfUnused(oldA)
        deleteIfUnused(oldB)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun clearPressed() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        val old = p.pressedFile
        p.pressedFile = null
        deleteIfUnused(old)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun changeInset() {
        val p = selectedPart()
        if (p == null || p.kind != "address") {
            toast("アドレス欄を選んでください")
            return
        }
        val labels = arrayOf("小（3%）", "中（6%）", "大（12%）")
        val values = floatArrayOf(0.03f, 0.06f, 0.12f)
        AlertDialog.Builder(activity)
            .setTitle("文字の左右の余白")
            .setItems(labels) { _, which ->
                p.textInset = values[which]
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun deleteIfUnused(name: String?) {
        if (name == null) return
        if (parts.none { it.imageFile == name || it.pressedFile == name }) File(store.imageDir, name).delete()
    }

    private fun changeAction() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンの機能は変更できません（編集に戻れなくなるため）")
            return
        }
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = (listOf("機能なし") + actions.map { it.label }).toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("割り当てる機能")
            .setItems(items) { _, which ->
                if (which == 0) {
                    p.action = ""
                } else {
                    p.action = actions[which - 1].name
                    if (p.imageFile == null) p.label = actions[which - 1].label
                }
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun deletePart() {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンは削除できません（編集に戻れなくなるため）")
            return
        }
        parts.remove(p)
        deleteIfUnused(p.imageFile)
        selectedId = null
        store.save(parts)
        rebuildParts()
        updatePanel()
    }

    private fun resizePart(factor: Float) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        p.w = (p.w * factor).coerceIn(0.05f, 1f)
        p.x = p.x.coerceIn(0f, maxOf(0f, 1f - p.w))
        if (p.kind == "address" || p.kind == "tabarea") rebuildParts() else layer.requestLayout()
        updateWebInsets()
        store.save(parts)
        updatePanel()
    }

    // ---------- 第4段階・後半：タブ一覧画面 ----------

    private fun showTabsScreen() {
        // タブ一覧エリアが削除されていたら、簡易な一覧ダイアログで代用する
        if (parts.none { it.screen == "tabs" && it.kind == "tabarea" }) {
            showTabList()
            return
        }
        setScreen("tabs")
    }

    private fun showBrowserScreen() {
        setScreen("browser")
    }

    /** 画面（ブラウザ画面 / タブ一覧画面）を切り替える。編集モードのままでも切り替えられる。 */
    private fun setScreen(screen: String) {
        if (screen == currentScreen) return
        if (findBar.visible) findBar.hide()
        if (screen == "tabs") core.captureThumb(core.currentTab) // 隠す前に、今のページを撮る
        currentScreen = screen
        selectedId = null
        webContainer.visibility = if (screen == "tabs") View.INVISIBLE else View.VISIBLE
        if (screen == "tabs") root.setBackgroundColor(Color.BLACK) else root.background = null
        rebuildParts()
        updatePanel()
    }

    private fun rebuildTabAreas() {
        for (p in parts) {
            if (p.kind != "tabarea" || p.screen != currentScreen) continue
            val v = views[p.id]
            if (v is TabAreaView) fillTabArea(p, v)
        }
    }

    /** タブ一覧エリアの中身（各タブのカード）を作る。 */
    private fun fillTabArea(p: UiPart, area: TabAreaView) {
        area.removeAllViews()
        val dm = activity.resources.displayMetrics
        val areaW = (dm.widthPixels * p.w).toInt()
        val gap = (8 * dm.density).toInt()
        val horizontal = p.tabMode == "hcards"
        val cols = if (p.tabMode == "grid") p.tabColumns.coerceIn(1, 4) else 1
        val itemW = if (horizontal) (areaW * 0.6f).toInt() else (areaW - gap * (cols + 1)) / cols
        val itemH = (itemW * p.itemAspect).toInt().coerceAtLeast(1)
        val m = gap / 2

        val content = LinearLayout(activity)
        content.setPadding(m, m, m, m)
        if (horizontal) {
            content.orientation = LinearLayout.HORIZONTAL
            for (i in core.tabs.indices) {
                val lp = LinearLayout.LayoutParams(itemW, itemH)
                lp.setMargins(m, m, m, m)
                content.addView(makeTabItem(p, i, itemH), lp)
            }
            val sv = HorizontalScrollView(activity)
            sv.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            area.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            content.orientation = LinearLayout.VERTICAL
            var row: LinearLayout? = null
            for (i in core.tabs.indices) {
                if (i % cols == 0) {
                    val r = LinearLayout(activity)
                    r.orientation = LinearLayout.HORIZONTAL
                    content.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    row = r
                }
                val lp = LinearLayout.LayoutParams(itemW, itemH)
                lp.setMargins(m, m, m, m)
                row?.addView(makeTabItem(p, i, itemH), lp)
            }
            val sv = ScrollView(activity)
            sv.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            area.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    /** 1枚のタブカード（サムネイル・タイトル・閉じるボタン）。 */
    private fun makeTabItem(p: UiPart, index: Int, itemH: Int): View {
        val tab = core.tabs[index]
        val dm = activity.resources.displayMetrics
        val card = FrameLayout(activity)
        val bg = GradientDrawable()
        bg.setColor(p.barColor)
        bg.cornerRadius = 12f * dm.density
        if (index == core.currentIndex) bg.setStroke((2 * dm.density).toInt(), 0xFF4FC3F7.toInt())
        card.background = bg
        card.clipToOutline = true

        val listStyle = p.tabMode == "list" // リストは「左にサムネイル・右にタイトル」の横並び
        val inner = LinearLayout(activity)
        inner.orientation = if (listStyle) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        if (p.tabThumb) {
            val iv = ImageView(activity)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = tab.thumb
            if (bmp != null) iv.setImageBitmap(bmp) else iv.setBackgroundColor(Color.argb(60, 255, 255, 255))
            if (listStyle) {
                inner.addView(iv, LinearLayout.LayoutParams(itemH, itemH))
            } else {
                inner.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, if (p.tabTitle) 3.5f else 1f))
            }
        }
        if (p.tabTitle) {
            val tv = TextView(activity)
            tv.text = tab.title
            tv.maxLines = if (listStyle) 2 else 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER_VERTICAL
            val pad = (8 * dm.density).toInt()
            tv.setPadding(pad, 0, pad, 0)
            applyTextStyle(tv, p, 12f)
            if (p.textColor == 0) tv.setTextColor(Color.WHITE)
            if (listStyle) {
                inner.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            } else {
                inner.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            }
        }
        card.addView(inner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (p.tabClose != "none") {
            val close = TextView(activity)
            close.text = "✕"
            close.gravity = Gravity.CENTER
            close.setTextColor(Color.WHITE)
            close.textSize = 14f
            val dot = GradientDrawable()
            dot.shape = GradientDrawable.OVAL
            dot.setColor(Color.argb(150, 0, 0, 0))
            close.background = dot
            val size = (30 * dm.density).toInt()
            val gravity = when (p.tabClose) {
                "bottomright" -> Gravity.BOTTOM or Gravity.END
                "topleft" -> Gravity.TOP or Gravity.START
                else -> Gravity.TOP or Gravity.END
            }
            val lp = FrameLayout.LayoutParams(size, size, gravity)
            val mg = (4 * dm.density).toInt()
            lp.setMargins(mg, mg, mg, mg)
            close.setOnClickListener { core.closeTab(index) }
            card.addView(close, lp)
        }

        card.setOnClickListener {
            core.switchTo(index)
            showBrowserScreen()
        }
        return card
    }

    private fun showTabModeDialog(p: UiPart) {
        val labels = arrayOf("リスト（左に画像・右に題名）", "グリッド（カードを格子状に）", "横カード（横にスクロール）")
        AlertDialog.Builder(activity)
            .setTitle("並べ方")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> {
                        p.tabMode = "list"
                        p.tabColumns = 1
                        p.itemAspect = 0.25f
                    }
                    1 -> {
                        p.tabMode = "grid"
                        p.tabColumns = 2
                        p.itemAspect = 1.2f
                    }
                    else -> {
                        p.tabMode = "hcards"
                        p.itemAspect = 1.4f
                    }
                }
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showTabColumnsDialog(p: UiPart) {
        val labels = arrayOf("1列", "2列", "3列", "4列")
        AlertDialog.Builder(activity)
            .setTitle("列の数")
            .setItems(labels) { _, which ->
                p.tabColumns = which + 1
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showTabCloseDialog(p: UiPart) {
        val labels = arrayOf("右上", "右下", "左上", "表示しない")
        val values = arrayOf("topright", "bottomright", "topleft", "none")
        AlertDialog.Builder(activity)
            .setTitle("閉じるボタンの位置")
            .setItems(labels) { _, which ->
                p.tabClose = values[which]
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showItemAspectDialog(p: UiPart) {
        val labels = arrayOf("0.2（とても横長）", "0.3", "0.5", "0.8", "1.0（正方形）", "1.3", "1.6（縦長）")
        val values = floatArrayOf(0.2f, 0.3f, 0.5f, 0.8f, 1.0f, 1.3f, 1.6f)
        AlertDialog.Builder(activity)
            .setTitle("カードの縦横比（高さ÷幅）")
            .setItems(labels) { _, which ->
                p.itemAspect = values[which]
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    // ---------- 第4段階・前半：文字スタイル・バー ----------

    private fun loadTypeface(name: String): Typeface? {
        return try {
            Typeface.createFromFile(File(store.fontDir, name))
        } catch (e: Exception) {
            null
        }
    }

    private fun applyTextStyle(tv: TextView, p: UiPart, defaultSp: Float) {
        tv.textSize = if (p.textSize > 0f) p.textSize else defaultSp
        if (p.textColor != 0) tv.setTextColor(p.textColor)
        typeface?.let { tv.typeface = it }
    }

    private fun applyOverlayStyle(iv: ShapedImageView, p: UiPart) {
        val sp = if (p.textSize > 0f) p.textSize else 14f
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, activity.resources.displayMetrics)
        iv.setOverlayStyle(if (p.textColor != 0) p.textColor else Color.WHITE, px, typeface)
    }

    /** 「タブ数」パーツに、今のタブの数を表示する。 */
    private fun updateTabCounts() {
        val n = core.tabs.size.toString()
        for (p in parts) {
            if (p.action != PartAction.TAB_COUNT.name) continue
            val v = views[p.id]
            if (v is Button) {
                v.text = n
            } else if (v is ShapedImageView) {
                v.setOverlayText(n)
            }
        }
    }

    /** 「ページを避ける」がONのバーの分だけ、Webページの表示範囲を狭める。 */
    private fun updateWebInsets() {
        val lw = layer.width
        val lh = layer.height
        if (lw <= 0 || lh <= 0) return
        var top = 0
        var bottom = 0
        for (p in parts) {
            if (p.kind != "bar" || !p.pushPage || p.screen != "browser") continue
            val ph = (p.w * lw * p.aspect).toInt().coerceIn(1, lh)
            val py = (p.y * lh).toInt().coerceIn(0, maxOf(0, lh - ph))
            if (py + ph / 2 < lh / 2) {
                top = maxOf(top, py + ph)
            } else {
                bottom = maxOf(bottom, lh - py)
            }
        }
        if (findBar.visible) top = maxOf(top, findBar.heightPx) // 検索バーの下にページを置く
        if (top != lastInsetTop || bottom != lastInsetBottom) {
            lastInsetTop = top
            lastInsetBottom = bottom
            val lp = webContainer.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = top
            lp.bottomMargin = bottom
            webContainer.layoutParams = lp
        }
    }

    /** バーの画像を「元の縦横比のまま」にする／引き伸ばし自由にする、を切り替える。 */
    private fun toggleBarLock(p: UiPart) {
        p.lockAspect = !p.lockAspect
        if (p.lockAspect) {
            val bmp = loadBitmap(p.imageFile)
            if (bmp != null) {
                p.aspect = bmp.height.toFloat() / bmp.width.toFloat()
                bmp.recycle()
            }
        }
        commit(p)
    }

    // ---------- 第5段階：デザインの切り替え・バックアップ ----------

    /** 別のデザインに切り替える（今のデザインは、切り替える前に保存済み）。 */
    private fun switchDesign(id: String) {
        designs.setActive(id)
        store = LayoutStore(activity, designs.dir(id))
        parts = store.load()
        selectedId = null
        pendingImagePartId = null
        lastInsetTop = -1
        lastInsetBottom = -1
        rebuildParts()
        applyFindBarColors()
        updatePanel()
        toast("デザインを切り替えました：" + designs.nameOf(id))
    }

    private fun startExport(ids: List<String>, fileName: String) {
        pendingExportIds = ids
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/zip"
        intent.putExtra(Intent.EXTRA_TITLE, fileName)
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_EXPORT)
    }

    /** 保存先が選ばれたあと、MainActivity から呼ばれる。 */
    fun onExportUri(uri: Uri) {
        try {
            store.save(parts)
            val out = activity.contentResolver.openOutputStream(uri)
            if (out == null) {
                toast("保存先を開けませんでした")
                return
            }
            out.use { designs.exportTo(pendingExportIds, it) }
            toast("バックアップを保存しました")
        } catch (e: Exception) {
            toast("バックアップに失敗しました")
        }
    }

    private fun startImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_IMPORT)
    }

    /** 復元するZIPが選ばれたあと、MainActivity から呼ばれる。 */
    fun onImportUri(uri: Uri) {
        try {
            val input = activity.contentResolver.openInputStream(uri)
            if (input == null) {
                toast("ファイルを開けませんでした")
                return
            }
            val n = input.use { designs.importFrom(it) }
            toast(if (n > 0) n.toString() + "個のデザインを復元しました" else "復元できるデザインが見つかりませんでした")
            designDialogs.show()
        } catch (e: Exception) {
            toast("復元に失敗しました（ZIPが壊れているか、大きすぎる可能性があります）")
        }
    }

    /**
     * アドレス欄の文字を、駅の電光掲示板のように流す（長いURLのとき）。
     * 入力欄そのものは文字を流せないので、入力欄の上に「流れる文字だけの表示」を重ねる。
     * タップすると重ね表示が消えて入力できる。入力が終わると、また流れる。
     */
    private fun setupMarquee(e: EditText, p: UiPart) {
        if (!p.scrollText) return
        val m = TextView(activity)
        m.setSingleLine(true)
        m.ellipsize = TextUtils.TruncateAt.MARQUEE
        m.marqueeRepeatLimit = -1
        m.isSelected = true
        m.gravity = Gravity.CENTER_VERTICAL
        m.setPadding(e.paddingLeft, 0, e.paddingRight, 0)
        applyTextStyle(m, p, 14f)
        e.hint = "" // 流れる文字の下に、案内の文字が透けないように
        m.isClickable = !editMode
        m.setOnClickListener { beginAddressEdit(e, m) }
        e.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                m.visibility = View.GONE
            } else {
                e.setText("")
                e.hint = ""
                m.visibility = View.VISIBLE
                updateOverlay(m)
            }
        }
        marqueeOverlays[p.id] = m
    }

    private fun beginAddressEdit(e: EditText, m: TextView) {
        m.visibility = View.GONE
        e.hint = "URLまたは検索ワード"
        e.setText(addressUrl)
        e.selectAll()
        e.requestFocus()
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(e, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun updateOverlay(m: TextView) {
        val p = m.tag as? UiPart
        if (addressUrl.isBlank()) {
            m.text = "URLまたは検索ワード"
            m.setTextColor(Color.GRAY)
        } else {
            m.text = addressUrl
            m.setTextColor(if (p != null && p.textColor != 0) p.textColor else Color.BLACK)
        }
    }

    /** 画像がGIFなら、動く画像に差し替える。 */
    private fun applyAnimation(iv: ShapedImageView, name: String?) {
        if (name == null || !name.endsWith(".gif")) return
        val d = GifSupport.load(File(store.imageDir, name)) ?: return
        iv.setAnimatedDrawable(d)
    }

    // ---------- ページ内検索バーの色 ----------

    private fun applyFindBarColors() {
        findBar.applyColors(store.findBarBg, store.findBarText, store.findBarBtn)
    }

    private fun saveFindBarColors() {
        store.save(parts)
        applyFindBarColors()
        findBar.show(false) // 色を確認できるよう、検索バーを表示する（✕で閉じられます）
    }

    private fun showFindBarColorMenu() {
        val items = arrayOf("背景の色", "文字の色", "ボタン（▲▼✕）の色", "初期の色に戻す")
        AlertDialog.Builder(activity)
            .setTitle("ページ内検索バーの色")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showColorDialog("検索バーの背景色", false) { c ->
                        store.findBarBg = if ((c ushr 24) == 0) 0 else c // 透明は読めなくなるので、標準色にする
                        saveFindBarColors()
                    }
                    1 -> showColorDialog("検索バーの文字の色", true) { c ->
                        store.findBarText = c
                        saveFindBarColors()
                    }
                    2 -> showColorDialog("検索バーのボタンの色", true) { c ->
                        store.findBarBtn = c
                        saveFindBarColors()
                    }
                    else -> {
                        store.findBarBg = 0
                        store.findBarText = 0
                        store.findBarBtn = 0
                        saveFindBarColors()
                    }
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
    }

    // ---------- 動画の全画面表示 ----------

    private fun showCustomView(v: View, cb: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            cb.onCustomViewHidden()
            return
        }
        customView = v
        customCallback = cb
        v.setBackgroundColor(Color.BLACK)
        root.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setSystemBarsHidden(true)
    }

    private fun hideCustomView() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        setSystemBarsHidden(false)
    }

    private fun setSystemBarsHidden(hide: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            val c = activity.window.insetsController ?: return
            if (hide) c.hide(WindowInsets.Type.systemBars()) else c.show(WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity.window.decorView.systemUiVisibility = if (hide) {
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            } else {
                0
            }
        }
    }

    private fun commit(p: UiPart) {
        store.save(parts)
        rebuildParts()
        select(p)
    }

    /** バー・アドレス欄・文字だけのボタンの高さを変える（画像のパーツは縦横比が固定）。 */
    private fun heightPart(factor: Float) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if ((p.kind != "bar" || p.lockAspect) && p.imageFile != null) {
            toast("画像のパーツは縦横比が固定です")
            return
        }
        p.aspect = (p.aspect * factor).coerceIn(0.03f, 2f)
        p.baseAspect = p.aspect
        layer.requestLayout()
        store.save(parts)
        updateWebInsets()
        updatePanel()
    }

    /** 「詳細」：選んだパーツの種類に合わせて、色・文字・フォントの設定を出す。 */
    private fun showDetailMenu() {
        val p = selectedPart()
        val items = mutableListOf<String>()
        val acts = mutableListOf<() -> Unit>()
        if (p != null && p.kind == "bar") {
            items.add("バーの色")
            acts.add { showColorDialog("バーの色", false) { c -> p.barColor = c; commit(p) } }
            items.add(if (p.pushPage) "ページを避ける：ON（タップで切替）" else "ページを避ける：OFF（タップで切替）")
            acts.add { p.pushPage = !p.pushPage; commit(p) }
            if (p.imageFile != null) {
                items.add(if (p.lockAspect) "画像の縦横比：固定中（タップで自由に）" else "画像の縦横比：自由（タップで固定）")
                acts.add { toggleBarLock(p) }
            }
        }
        if (p != null && p.kind == "address") {
            items.add(if (p.scrollText) "文字を流す：ON（タップで切替）" else "文字を流す：OFF（タップで切替）")
            acts.add { p.scrollText = !p.scrollText; commit(p) }
        }
        if (p != null && p.kind == "tabarea") {
            items.add("並べ方（リスト／グリッド／横カード）")
            acts.add { showTabModeDialog(p) }
            if (p.tabMode == "grid") {
                items.add("列の数")
                acts.add { showTabColumnsDialog(p) }
            }
            items.add(if (p.tabThumb) "サムネイル：表示中（タップで切替）" else "サムネイル：非表示（タップで切替）")
            acts.add { p.tabThumb = !p.tabThumb; commit(p) }
            items.add(if (p.tabTitle) "タイトル：表示中（タップで切替）" else "タイトル：非表示（タップで切替）")
            acts.add { p.tabTitle = !p.tabTitle; commit(p) }
            items.add("閉じるボタンの位置")
            acts.add { showTabCloseDialog(p) }
            items.add("カードの縦横比")
            acts.add { showItemAspectDialog(p) }
            items.add("カードの色")
            acts.add { showColorDialog("カードの色", false) { c -> p.barColor = c; commit(p) } }
        }
        if (p != null && p.kind != "bar") {
            items.add("文字の色")
            acts.add { showColorDialog("文字の色", true) { c -> p.textColor = c; commit(p) } }
            items.add("文字のサイズ")
            acts.add { showTextSizeDialog(p) }
        }
        items.add("フォントを選ぶ（全体に適用）")
        acts.add { pickFont() }
        if (store.fontFile != null) {
            items.add("フォントを標準に戻す")
            acts.add { clearFont() }
        }
        items.add("ページ内検索バーの色")
        acts.add { showFindBarColorMenu() }
        items.add("デザインの管理（切替・保存・バックアップ）")
        acts.add { designDialogs.show() }
        AlertDialog.Builder(activity)
            .setTitle("詳細設定")
            .setItems(items.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showColorDialog(title: String, forText: Boolean, onPick: (Int) -> Unit) {
        val names = mutableListOf<String>()
        val values = mutableListOf<Int>()
        if (forText) {
            names.add("標準")
            values.add(0)
        }
        for (i in COLOR_NAMES.indices) {
            if (forText && COLOR_VALUES[i] == 0) continue // 文字色に「透明」は使わない
            names.add(COLOR_NAMES[i])
            values.add(COLOR_VALUES[i])
        }
        names.add("色コードを入力")
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, which ->
                if (which < values.size) onPick(values[which]) else showHexInput(onPick)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showHexInput(onPick: (Int) -> Unit) {
        val input = EditText(activity)
        input.isSingleLine = true
        input.hint = "#RRGGBB（例 #FF8800）"
        AlertDialog.Builder(activity)
            .setTitle("色コード")
            .setView(input)
            .setPositiveButton("決定") { _, _ ->
                try {
                    onPick(Color.parseColor(input.text.toString().trim()))
                } catch (e: Exception) {
                    toast("色コードが正しくありません")
                }
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showTextSizeDialog(p: UiPart) {
        val labels = arrayOf("標準", "小さい（10）", "12", "14", "16", "18", "大きい（22）", "特大（28）")
        val values = floatArrayOf(0f, 10f, 12f, 14f, 16f, 18f, 22f, 28f)
        AlertDialog.Builder(activity)
            .setTitle("文字のサイズ")
            .setItems(labels) { _, which ->
                p.textSize = values[which]
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun pickFont() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_FONT)
    }

    /** フォントファイルが選ばれたあと、MainActivity から呼ばれる。 */
    fun onFontPicked(uri: Uri) {
        val name = store.importFont(uri)
        if (name == null) {
            toast("フォントを読み込めませんでした（.ttf / .otf を選んでください）")
            return
        }
        val old = store.fontFile
        store.fontFile = name
        if (old != null) File(store.fontDir, old).delete()
        store.save(parts)
        rebuildParts()
    }

    private fun clearFont() {
        val old = store.fontFile ?: return
        store.fontFile = null
        File(store.fontDir, old).delete()
        store.save(parts)
        rebuildParts()
    }

    private fun confirmReset() {
        AlertDialog.Builder(activity)
            .setTitle("初期状態に戻す")
            .setMessage("ボタンの配置・サイズ・画像・フォントをすべて初期状態に戻します。")
            .setPositiveButton("戻す") { _, _ ->
                val oldImages = parts.flatMap { listOfNotNull(it.imageFile, it.pressedFile) }
                parts = store.defaultLayout()
                store.fontFile?.let { File(store.fontDir, it).delete() }
                store.fontFile = null
                selectedId = null
                store.save(parts)
                for (n in oldImages) File(store.imageDir, n).delete()
                rebuildParts()
                updatePanel()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }
}
