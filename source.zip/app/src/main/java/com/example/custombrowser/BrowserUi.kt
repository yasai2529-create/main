package com.example.custombrowser

// ============================================================
// 見た目を担当。パーツ（UiPart）の一覧から画面を組み立てます。
// 通常モード：パーツを押すと機能が動く
// 編集モード：パーツをドラッグ・選択して、大きさ・画像・機能を変える
// ブラウザの機能は BrowserCore を呼ぶだけです。
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class BrowserUi(
    private val activity: Activity,
    private val core: BrowserCore
) : BrowserListener {

    companion object {
        const val REQ_IMAGE = 1001
    }

    val root = FrameLayout(activity)
    private val webContainer = FrameLayout(activity)
    private val layer = PartsLayer(activity)
    private val panel = LinearLayout(activity)
    private val panelTitle = TextView(activity)

    private val store = LayoutStore(activity)
    private var parts: MutableList<UiPart> = store.load()
    private val views = HashMap<String, View>()
    private val addressBars = mutableListOf<EditText>()

    private var editMode = false
    private var selectedId: String? = null
    private var pendingImagePartId: String? = null

    init {
        root.addView(
            webContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            layer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        buildPanel()
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        panel.visibility = View.GONE
        rebuildParts()
    }

    // ---------- BrowserListener ----------

    override fun onTabChanged() {
        webContainer.removeAllViews()
        val tab = core.currentTab ?: return
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setAddressText(tab.url)
    }

    override fun onPageInfo(tab: Tab) {
        if (tab == core.currentTab) setAddressText(tab.url)
    }

    private fun setAddressText(url: String) {
        for (e in addressBars) {
            if (!e.hasFocus()) e.setText(url)
        }
    }

    // ---------- パーツの作成 ----------

    private fun rebuildParts() {
        layer.removeAllViews()
        views.clear()
        addressBars.clear()
        for (p in parts) {
            val v = createView(p)
            v.tag = p
            views[p.id] = v
            layer.addView(v)
        }
        refreshSelection()
        core.currentTab?.let { setAddressText(it.url) }
    }

    private fun createView(p: UiPart): View {
        val v: View
        if (p.kind == "address") {
            val e = EditText(activity)
            e.isSingleLine = true
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            e.imeOptions = EditorInfo.IME_ACTION_GO
            e.hint = "URLまたは検索ワード"
            e.textSize = 14f
            val bg = GradientDrawable()
            bg.setColor(Color.WHITE)
            bg.setStroke(2, Color.GRAY)
            bg.cornerRadius = 16f
            e.background = bg
            e.setPadding(16, 0, 16, 0)
            e.setOnEditorActionListener { tv, _, _ ->
                core.openInput(tv.text.toString())
                hideKeyboard(tv)
                true
            }
            addressBars.add(e)
            v = e
        } else {
            val file = p.imageFile?.let { File(store.imageDir, it) }
            val bmp = if (file != null && file.exists()) BitmapFactory.decodeFile(file.path) else null
            if (bmp != null) {
                val iv = ImageView(activity)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.setImageBitmap(bmp)
                iv.setOnClickListener { runAction(p) }
                v = iv
            } else {
                val b = Button(activity)
                b.text = p.label
                b.textSize = 12f
                b.isAllCaps = false
                b.setPadding(0, 0, 0, 0)
                b.minWidth = 0
                b.minimumWidth = 0
                b.minHeight = 0
                b.minimumHeight = 0
                b.setOnClickListener { runAction(p) }
                v = b
            }
        }
        attachTouch(v, p)
        return v
    }

    /** 編集モードのときだけ、ドラッグ移動と選択を行う。通常モードでは何もしない。 */
    private fun attachTouch(v: View, p: UiPart) {
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        v.setOnTouchListener { _, e ->
            if (!editMode) {
                false
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        select(p)
                        downX = e.rawX
                        downY = e.rawY
                        startX = p.x
                        startY = p.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val lw = layer.width.toFloat()
                        val lh = layer.height.toFloat()
                        if (lw > 0f && lh > 0f) {
                            p.x = (startX + (e.rawX - downX) / lw).coerceIn(0f, maxOf(0f, 1f - p.w))
                            p.y = (startY + (e.rawY - downY) / lh).coerceIn(0f, maxOf(0f, 1f - heightFrac(p)))
                            layer.requestLayout()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        store.save(parts)
                        updatePanel()
                    }
                }
                true
            }
        }
    }

    private fun heightFrac(p: UiPart): Float {
        val lw = layer.width.toFloat()
        val lh = layer.height.toFloat()
        return if (lh <= 0f) 0f else p.w * lw * p.aspect / lh
    }

    // ---------- 機能の実行 ----------

    private fun runAction(p: UiPart) {
        when (PartAction.fromName(p.action)) {
            PartAction.BACK -> core.goBack()
            PartAction.FORWARD -> core.goForward()
            PartAction.RELOAD -> core.reload()
            PartAction.HOME -> core.goHome()
            PartAction.NEW_TAB -> core.newTab()
            PartAction.TAB_LIST -> showTabList()
            PartAction.CLOSE_TAB -> core.closeCurrentTab()
            PartAction.SEARCH_DIALOG -> showSearchDialog()
            PartAction.EDIT_MODE -> setEditMode(true)
            null -> {}
        }
    }

    private fun showTabList() {
        val titles = core.tabs.mapIndexed { i, t ->
            (if (i == core.currentIndex) "● " else "") + t.title
        }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("タブ一覧")
            .setItems(titles) { _, which -> core.switchTo(which) }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showSearchDialog() {
        val input = EditText(activity)
        input.isSingleLine = true
        AlertDialog.Builder(activity)
            .setTitle("URLまたは検索ワード")
            .setView(input)
            .setPositiveButton("開く") { _, _ -> core.openInput(input.text.toString()) }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun hideKeyboard(v: View) {
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun toast(msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- 編集モード ----------

    fun onBack(): Boolean {
        if (editMode) {
            setEditMode(false)
            return true
        }
        return false
    }

    private fun setEditMode(on: Boolean) {
        editMode = on
        selectedId = null
        if (!on) store.save(parts)
        panel.visibility = if (on) View.VISIBLE else View.GONE
        refreshSelection()
        updatePanel()
    }

    private fun selectedPart(): UiPart? = parts.firstOrNull { it.id == selectedId }

    private fun select(p: UiPart) {
        selectedId = p.id
        refreshSelection()
        updatePanel()
    }

    /** 編集中は枠線を表示。選択中のパーツは赤い太枠。 */
    private fun refreshSelection() {
        for (p in parts) {
            val v = views[p.id] ?: continue
            if (!editMode) {
                v.foreground = null
            } else {
                val d = GradientDrawable()
                d.setColor(Color.TRANSPARENT)
                if (p.id == selectedId) d.setStroke(6, Color.RED) else d.setStroke(2, Color.GRAY)
                v.foreground = d
            }
        }
    }

    private fun updatePanel() {
        val sel = selectedPart()
        panelTitle.text = if (sel == null) {
            "編集モード：パーツをタップして選択"
        } else if (sel.kind == "address") {
            "選択中：アドレス欄"
        } else {
            "選択中：" + sel.label + "（" + (PartAction.fromName(sel.action)?.label ?: "") + "）"
        }
        // 選んだパーツに操作パネルが重ならないよう、上下を入れ替える
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (sel != null && sel.y + heightFrac(sel) / 2f > 0.5f) Gravity.TOP else Gravity.BOTTOM
        panel.layoutParams = lp
    }

    private fun buildPanel() {
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.argb(235, 40, 40, 40))
        panel.setPadding(8, 8, 8, 8)
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.textSize = 13f
        panel.addView(panelTitle)

        val row1 = LinearLayout(activity)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(panelButton("＋追加") { addPart() }, weightParams())
        row1.addView(panelButton("画像") { pickImage() }, weightParams())
        row1.addView(panelButton("画像戻す") { clearImage() }, weightParams())
        row1.addView(panelButton("機能") { changeAction() }, weightParams())
        row1.addView(panelButton("削除") { deletePart() }, weightParams())

        val row2 = LinearLayout(activity)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(panelButton("小さく") { resizePart(0.87f) }, weightParams())
        row2.addView(panelButton("大きく") { resizePart(1.15f) }, weightParams())
        row2.addView(panelButton("初期化") { confirmReset() }, weightParams())
        row2.addView(panelButton("完了") { setEditMode(false) }, weightParams())

        panel.addView(row1)
        panel.addView(row2)
    }

    private fun panelButton(label: String, onClick: () -> Unit): Button {
        val b = Button(activity)
        b.text = label
        b.textSize = 11f
        b.isAllCaps = false
        b.setPadding(0, 0, 0, 0)
        b.minWidth = 0
        b.minimumWidth = 0
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    // ---------- 編集の操作 ----------

    private fun newId(): String = java.util.UUID.randomUUID().toString().take(8)

    private fun addPart() {
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = (listOf("アドレス欄") + actions.map { it.label }).toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("追加するパーツ")
            .setItems(items) { _, which ->
                val p = if (which == 0) {
                    UiPart(newId(), "address", "", "アドレス欄", 0.25f, 0.4f, 0.5f, 0.16f, 0.16f)
                } else {
                    val a = actions[which - 1]
                    UiPart(newId(), "button", a.name, a.label, 0.4f, 0.4f, 0.2f, 0.5f, 0.5f)
                }
                parts.add(p)
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun pickImage() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("画像を設定するボタンを選んでください")
            return
        }
        pendingImagePartId = p.id
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_IMAGE)
    }

    /** 画像が選ばれたあと、MainActivity から呼ばれる。 */
    fun onImagePicked(uri: Uri) {
        val id = pendingImagePartId ?: return
        val p = parts.firstOrNull { it.id == id } ?: return
        val name = store.importImage(uri)
        if (name == null) {
            toast("画像を読み込めませんでした")
            return
        }
        val bmp = BitmapFactory.decodeFile(File(store.imageDir, name).path)
        if (bmp == null) {
            toast("画像を読み込めませんでした")
            return
        }
        p.aspect = bmp.height.toFloat() / bmp.width.toFloat()
        bmp.recycle()
        val old = p.imageFile
        p.imageFile = name
        deleteIfUnused(old)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun clearImage() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        val old = p.imageFile
        p.imageFile = null
        p.aspect = p.baseAspect
        deleteIfUnused(old)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun deleteIfUnused(name: String?) {
        if (name == null) return
        if (parts.none { it.imageFile == name }) File(store.imageDir, name).delete()
    }

    private fun changeAction() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンの機能は変更できません（編集に戻れなくなるため）")
            return
        }
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = actions.map { it.label }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("割り当てる機能")
            .setItems(items) { _, which ->
                p.action = actions[which].name
                if (p.imageFile == null) p.label = actions[which].label
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun deletePart() {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンは削除できません（編集に戻れなくなるため）")
            return
        }
        parts.remove(p)
        deleteIfUnused(p.imageFile)
        selectedId = null
        store.save(parts)
        rebuildParts()
        updatePanel()
    }

    private fun resizePart(factor: Float) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        p.w = (p.w * factor).coerceIn(0.05f, 1f)
        p.x = p.x.coerceIn(0f, maxOf(0f, 1f - p.w))
        layer.requestLayout()
        store.save(parts)
        updatePanel()
    }

    private fun confirmReset() {
        AlertDialog.Builder(activity)
            .setTitle("初期状態に戻す")
            .setMessage("ボタンの配置・サイズ・画像をすべて初期状態に戻します。")
            .setPositiveButton("戻す") { _, _ ->
                val oldImages = parts.mapNotNull { it.imageFile }
                parts = store.defaultLayout()
                selectedId = null
                store.save(parts)
                for (n in oldImages) File(store.imageDir, n).delete()
                rebuildParts()
                updatePanel()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }
}
