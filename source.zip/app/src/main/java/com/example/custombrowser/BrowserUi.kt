package com.example.custombrowser

// ============================================================
// 見た目（ボタン・アドレスバーの配置）を担当。
// 第1段階では固定のレイアウト。第2段階以降でここを自由に編集できるようにします。
// ブラウザの機能は BrowserCore を呼ぶだけ。
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

class BrowserUi(
    private val activity: Activity,
    private val core: BrowserCore
) : BrowserListener {

    val root = LinearLayout(activity)
    private val container = FrameLayout(activity)
    private val addressBar = EditText(activity)

    init {
        root.orientation = LinearLayout.VERTICAL

        // 上のバー：戻る・進む・更新・アドレス欄
        val top = LinearLayout(activity)
        top.orientation = LinearLayout.HORIZONTAL
        top.addView(makeButton("◀") { core.goBack() })
        top.addView(makeButton("▶") { core.goForward() })
        top.addView(makeButton("↻") { core.reload() })

        addressBar.isSingleLine = true
        addressBar.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addressBar.imeOptions = EditorInfo.IME_ACTION_GO
        addressBar.hint = "URLまたは検索ワード"
        addressBar.setOnEditorActionListener { v, _, _ ->
            core.openInput(v.text.toString())
            hideKeyboard()
            true
        }
        top.addView(
            addressBar,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        // 下のバー：ホーム・タブ追加・タブ一覧・タブを閉じる
        val bottom = LinearLayout(activity)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.addView(makeButton("ホーム") { core.goHome() }, weightParams())
        bottom.addView(makeButton("＋タブ") { core.newTab() }, weightParams())
        bottom.addView(makeButton("タブ一覧") { showTabList() }, weightParams())
        bottom.addView(makeButton("×閉じる") { core.closeCurrentTab() }, weightParams())

        root.addView(top)
        root.addView(
            container,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(bottom)
    }

    // ---------- BrowserListener ----------

    override fun onTabChanged() {
        container.removeAllViews()
        val tab = core.currentTab ?: return
        container.addView(
            tab.webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        addressBar.setText(tab.url)
    }

    override fun onPageInfo(tab: Tab) {
        if (tab == core.currentTab && !addressBar.hasFocus()) {
            addressBar.setText(tab.url)
        }
    }

    // ---------- 内部の道具 ----------

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        val b = Button(activity)
        b.text = label
        b.minWidth = 0
        b.minimumWidth = 0
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun hideKeyboard() {
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(addressBar.windowToken, 0)
        addressBar.clearFocus()
    }

    private fun showTabList() {
        val titles = core.tabs.mapIndexed { i, t ->
            (if (i == core.currentIndex) "● " else "") + t.title
        }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("タブ一覧")
            .setItems(titles) { _, which -> core.switchTo(which) }
            .setNegativeButton("閉じる", null)
            .show()
    }
}
