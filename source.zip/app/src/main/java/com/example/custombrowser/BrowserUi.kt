package com.example.custombrowser

// ============================================================
// 見た目を担当。パーツ（UiPart）の一覧から画面を組み立てます。
// 通常モード：パーツを押すと機能が動く
// 編集モード：パーツをドラッグ・選択して、大きさ・画像・機能を変える
// ブラウザの機能は BrowserCore を呼ぶだけです。
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class BrowserUi(
    private val activity: Activity,
    private val core: BrowserCore
) : BrowserListener {

    companion object {
        const val REQ_IMAGE = 1001
        const val REQ_FONT = 1002

        val COLOR_NAMES = arrayOf(
            "ダークグレー", "黒", "白", "ライトグレー", "青", "水色",
            "赤", "ピンク", "緑", "黄", "茶", "透明"
        )
        val COLOR_VALUES = intArrayOf(
            0xFF2B2B2B.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFE0E0E0.toInt(),
            0xFF1E5BD8.toInt(), 0xFF4FC3F7.toInt(), 0xFFD32F2F.toInt(), 0xFFF48FB1.toInt(),
            0xFF2E7D32.toInt(), 0xFFFFEB3B.toInt(), 0xFF5D4037.toInt(), 0x00000000
        )
    }

    val root = FrameLayout(activity)
    private val webContainer = FrameLayout(activity)
    private val layer = PartsLayer(activity)
    private val panel = LinearLayout(activity)
    private val panelTitle = TextView(activity)

    private val store = LayoutStore(activity)
    private var parts: MutableList<UiPart> = store.load()
    private val views = HashMap<String, View>()
    private val addressBars = mutableListOf<EditText>()

    private var editMode = false
    private var selectedId: String? = null
    private var pendingImagePartId: String? = null
    private var pendingPressed = false
    private var panelOnTop = false
    private var typeface: Typeface? = null
    private var lastInsetTop = -1
    private var lastInsetBottom = -1

    init {
        root.addView(
            webContainer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root.addView(
            layer,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        buildPanel()
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
        )
        panel.visibility = View.GONE
        rebuildParts()
        // 画面サイズ・向きが変わったら、バーに合わせてページの位置を調整し直す
        layer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> root.post { updateWebInsets() } }
    }

    // ---------- BrowserListener ----------

    override fun onTabChanged() {
        webContainer.removeAllViews()
        updateTabCounts()
        val tab = core.currentTab ?: return
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setAddressText(tab.url)
    }

    override fun onPageInfo(tab: Tab) {
        if (tab == core.currentTab) setAddressText(tab.url)
    }

    private fun setAddressText(url: String) {
        for (e in addressBars) {
            if (!e.hasFocus()) e.setText(url)
        }
    }

    // ---------- パーツの作成 ----------

    private fun rebuildParts() {
        typeface = store.fontFile?.let { loadTypeface(it) }
        layer.removeAllViews()
        views.clear()
        addressBars.clear()
        for (p in parts) {
            val v = createView(p)
            v.tag = p
            views[p.id] = v
            layer.addView(v)
        }
        refreshSelection()
        updateTabCounts()
        core.currentTab?.let { setAddressText(it.url) }
        root.post { updateWebInsets() }
    }

    private fun createView(p: UiPart): View {
        val v: View
        if (p.kind == "address") {
            val e = EditText(activity)
            e.isSingleLine = true
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            e.imeOptions = EditorInfo.IME_ACTION_GO
            e.hint = "URLまたは検索ワード"
            e.textSize = 14f
            val bgBmp = loadBitmap(p.imageFile)
            if (bgBmp != null) {
                e.background = BitmapDrawable(activity.resources, bgBmp)
            } else {
                val bg = GradientDrawable()
                bg.setColor(Color.WHITE)
                bg.setStroke(2, Color.GRAY)
                bg.cornerRadius = 16f
                e.background = bg
            }
            e.gravity = Gravity.CENTER_VERTICAL
            val inset = (activity.resources.displayMetrics.widthPixels * p.w * p.textInset).toInt()
            e.setPadding(maxOf(inset, 16), 0, maxOf(inset, 16), 0)
            e.setOnEditorActionListener { tv, _, _ ->
                core.openInput(tv.text.toString())
                hideKeyboard(tv)
                true
            }
            applyTextStyle(e, p, 14f)
            addressBars.add(e)
            v = e
        } else if (p.kind == "bar") {
            val bv = View(activity)
            val barBmp = loadBitmap(p.imageFile)
            if (barBmp != null) {
                bv.background = BitmapDrawable(activity.resources, barBmp)
            } else {
                bv.setBackgroundColor(p.barColor)
            }
            bv.isClickable = true // バーの下のページを触ってしまわないよう、タップを受け止める
            v = bv
        } else {
            val bmp = loadBitmap(p.imageFile)
            if (bmp != null) {
                val iv = ShapedImageView(activity)
                iv.setImages(bmp, loadBitmap(p.pressedFile))
                applyOverlayStyle(iv, p)
                iv.setOnClickListener { runAction(p) }
                v = iv
            } else {
                val b = Button(activity)
                b.text = p.label
                b.textSize = 12f
                b.isAllCaps = false
                b.setPadding(0, 0, 0, 0)
                b.minWidth = 0
                b.minimumWidth = 0
                b.minHeight = 0
                b.minimumHeight = 0
                applyTextStyle(b, p, 12f)
                b.setOnClickListener { runAction(p) }
                v = b
            }
        }
        attachTouch(v, p)
        return v
    }

    /** 編集モードのときだけ、ドラッグ移動と選択を行う。通常モードでは何もしない。 */
    private fun attachTouch(v: View, p: UiPart) {
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        v.setOnTouchListener { _, e ->
            if (!editMode) {
                false
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        select(p)
                        downX = e.rawX
                        downY = e.rawY
                        startX = p.x
                        startY = p.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val lw = layer.width.toFloat()
                        val lh = layer.height.toFloat()
                        if (lw > 0f && lh > 0f) {
                            p.x = (startX + (e.rawX - downX) / lw).coerceIn(0f, maxOf(0f, 1f - p.w))
                            p.y = (startY + (e.rawY - downY) / lh).coerceIn(0f, maxOf(0f, 1f - heightFrac(p)))
                            layer.requestLayout()
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        store.save(parts)
                        updateWebInsets()
                        updatePanel()
                    }
                }
                true
            }
        }
    }

    private fun loadBitmap(name: String?): Bitmap? {
        if (name == null) return null
        val f = File(store.imageDir, name)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun heightFrac(p: UiPart): Float {
        val lw = layer.width.toFloat()
        val lh = layer.height.toFloat()
        return if (lh <= 0f) 0f else p.w * lw * p.aspect / lh
    }

    // ---------- 機能の実行 ----------

    private fun runAction(p: UiPart) {
        when (PartAction.fromName(p.action)) {
            PartAction.BACK -> core.goBack()
            PartAction.FORWARD -> core.goForward()
            PartAction.RELOAD -> core.reload()
            PartAction.HOME -> core.goHome()
            PartAction.NEW_TAB -> core.newTab()
            PartAction.TAB_LIST -> showTabList()
            PartAction.TAB_COUNT -> showTabList()
            PartAction.CLOSE_TAB -> core.closeCurrentTab()
            PartAction.SEARCH_DIALOG -> showSearchDialog()
            PartAction.EDIT_MODE -> setEditMode(true)
            null -> {}
        }
    }

    private fun showTabList() {
        val titles = core.tabs.mapIndexed { i, t ->
            (if (i == core.currentIndex) "● " else "") + t.title
        }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("タブ一覧")
            .setItems(titles) { _, which -> core.switchTo(which) }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showSearchDialog() {
        val input = EditText(activity)
        input.isSingleLine = true
        AlertDialog.Builder(activity)
            .setTitle("URLまたは検索ワード")
            .setView(input)
            .setPositiveButton("開く") { _, _ -> core.openInput(input.text.toString()) }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun hideKeyboard(v: View) {
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
        v.clearFocus()
    }

    private fun toast(msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- 編集モード ----------

    fun onBack(): Boolean {
        if (editMode) {
            setEditMode(false)
            return true
        }
        return false
    }

    private fun setEditMode(on: Boolean) {
        editMode = on
        selectedId = null
        if (!on) store.save(parts)
        panel.visibility = if (on) View.VISIBLE else View.GONE
        if (on) toast("パネルに隠れたパーツは「▲▼移動」で上下に動かして編集できます")
        refreshSelection()
        updatePanel()
    }

    private fun selectedPart(): UiPart? = parts.firstOrNull { it.id == selectedId }

    private fun select(p: UiPart) {
        selectedId = p.id
        refreshSelection()
        updatePanel()
    }

    /** 編集中は枠線を表示。選択中のパーツは赤い太枠。 */
    private fun refreshSelection() {
        for (p in parts) {
            val v = views[p.id] ?: continue
            if (!editMode) {
                v.foreground = null
            } else {
                val d = GradientDrawable()
                d.setColor(Color.TRANSPARENT)
                if (p.id == selectedId) d.setStroke(6, Color.RED) else d.setStroke(2, Color.GRAY)
                v.foreground = d
            }
        }
    }

    private fun updatePanel() {
        val sel = selectedPart()
        panelTitle.text = if (sel == null) {
            "編集モード：パーツをタップして選択"
        } else if (sel.kind == "address") {
            "選択中：アドレス欄"
        } else if (sel.kind == "bar") {
            "選択中：バー"
        } else {
            "選択中：" + sel.label + "（" + (PartAction.fromName(sel.action)?.label ?: "") + "）"
        }
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (panelOnTop) Gravity.TOP else Gravity.BOTTOM
        panel.layoutParams = lp
    }

    private fun buildPanel() {
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(Color.argb(235, 40, 40, 40))
        panel.setPadding(8, 8, 8, 8)
        panelTitle.setTextColor(Color.WHITE)
        panelTitle.textSize = 13f
        val header = LinearLayout(activity)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(panelTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(panelButton("▲▼移動") { togglePanelSide() })
        panel.addView(header)

        val row1 = LinearLayout(activity)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(panelButton("＋追加") { addPart() }, weightParams())
        row1.addView(panelButton("画像") { pickImage(false) }, weightParams())
        row1.addView(panelButton("画像戻す") { clearImage() }, weightParams())
        row1.addView(panelButton("機能") { changeAction() }, weightParams())
        row1.addView(panelButton("削除") { deletePart() }, weightParams())

        val row2 = LinearLayout(activity)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(panelButton("小さく") { resizePart(0.87f) }, weightParams())
        row2.addView(panelButton("大きく") { resizePart(1.15f) }, weightParams())
        row2.addView(panelButton("高く") { heightPart(1.15f) }, weightParams())
        row2.addView(panelButton("低く") { heightPart(0.87f) }, weightParams())
        row2.addView(panelButton("初期化") { confirmReset() }, weightParams())
        row2.addView(panelButton("完了") { setEditMode(false) }, weightParams())

        val row3 = LinearLayout(activity)
        row3.orientation = LinearLayout.HORIZONTAL
        row3.addView(panelButton("押下画像") { pickImage(true) }, weightParams())
        row3.addView(panelButton("押下戻す") { clearPressed() }, weightParams())
        row3.addView(panelButton("余白") { changeInset() }, weightParams())
        row3.addView(panelButton("詳細") { showDetailMenu() }, weightParams())

        panel.addView(row1)
        panel.addView(row2)
        panel.addView(row3)
    }

    /** 操作パネルを画面の上側／下側に動かす（隠れているパーツを編集するため）。 */
    private fun togglePanelSide() {
        panelOnTop = !panelOnTop
        updatePanel()
    }

    private fun panelButton(label: String, onClick: () -> Unit): Button {
        val b = Button(activity)
        b.text = label
        b.textSize = 11f
        b.isAllCaps = false
        b.setPadding(0, 0, 0, 0)
        b.minWidth = 0
        b.minimumWidth = 0
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    // ---------- 編集の操作 ----------

    private fun newId(): String = java.util.UUID.randomUUID().toString().take(8)

    private fun addPart() {
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = (listOf("アドレス欄", "バー（帯）") + actions.map { it.label }).toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("追加するパーツ")
            .setItems(items) { _, which ->
                val p = if (which == 0) {
                    UiPart(newId(), "address", "", "アドレス欄", 0.25f, 0.4f, 0.5f, 0.16f, 0.16f)
                } else if (which == 1) {
                    UiPart(newId(), "bar", "", "バー", 0.0f, 0.4f, 1.0f, 0.12f, 0.12f)
                } else {
                    val a = actions[which - 2]
                    UiPart(newId(), "button", a.name, a.label, 0.4f, 0.4f, 0.2f, 0.5f, 0.5f)
                }
                // バーは他のパーツの下に敷くので、先頭に入れる
                if (p.kind == "bar") parts.add(0, p) else parts.add(p)
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun pickImage(pressed: Boolean) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (pressed) {
            if (p.kind == "address") {
                toast("押したときの画像はボタン専用です")
                return
            }
            if (p.imageFile == null) {
                toast("先に通常の画像を設定してください")
                return
            }
        }
        pendingImagePartId = p.id
        pendingPressed = pressed
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_IMAGE)
    }

    /** 画像が選ばれたあと、MainActivity から呼ばれる。 */
    fun onImagePicked(uri: Uri) {
        val id = pendingImagePartId ?: return
        val p = parts.firstOrNull { it.id == id } ?: return
        val name = store.importImage(uri)
        if (name == null) {
            toast("画像を読み込めませんでした")
            return
        }
        val bmp = BitmapFactory.decodeFile(File(store.imageDir, name).path)
        if (bmp == null) {
            toast("画像を読み込めませんでした")
            return
        }
        if (pendingPressed) {
            bmp.recycle()
            val old = p.pressedFile
            p.pressedFile = name
            deleteIfUnused(old)
        } else {
            if (p.kind != "bar") p.aspect = bmp.height.toFloat() / bmp.width.toFloat()
            bmp.recycle()
            val old = p.imageFile
            p.imageFile = name
            deleteIfUnused(old)
        }
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun clearImage() {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        val oldA = p.imageFile
        val oldB = p.pressedFile
        p.imageFile = null
        p.pressedFile = null
        if (p.kind != "bar") p.aspect = p.baseAspect
        deleteIfUnused(oldA)
        deleteIfUnused(oldB)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun clearPressed() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        val old = p.pressedFile
        p.pressedFile = null
        deleteIfUnused(old)
        store.save(parts)
        rebuildParts()
        select(p)
    }

    private fun changeInset() {
        val p = selectedPart()
        if (p == null || p.kind != "address") {
            toast("アドレス欄を選んでください")
            return
        }
        val labels = arrayOf("小（3%）", "中（6%）", "大（12%）")
        val values = floatArrayOf(0.03f, 0.06f, 0.12f)
        AlertDialog.Builder(activity)
            .setTitle("文字の左右の余白")
            .setItems(labels) { _, which ->
                p.textInset = values[which]
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun deleteIfUnused(name: String?) {
        if (name == null) return
        if (parts.none { it.imageFile == name || it.pressedFile == name }) File(store.imageDir, name).delete()
    }

    private fun changeAction() {
        val p = selectedPart()
        if (p == null || p.kind == "address") {
            toast("ボタンを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンの機能は変更できません（編集に戻れなくなるため）")
            return
        }
        val actions = PartAction.values().filter { it != PartAction.EDIT_MODE }
        val items = actions.map { it.label }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("割り当てる機能")
            .setItems(items) { _, which ->
                p.action = actions[which].name
                if (p.imageFile == null) p.label = actions[which].label
                store.save(parts)
                rebuildParts()
                select(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun deletePart() {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (p.action == PartAction.EDIT_MODE.name) {
            toast("編集ボタンは削除できません（編集に戻れなくなるため）")
            return
        }
        parts.remove(p)
        deleteIfUnused(p.imageFile)
        selectedId = null
        store.save(parts)
        rebuildParts()
        updatePanel()
    }

    private fun resizePart(factor: Float) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        p.w = (p.w * factor).coerceIn(0.05f, 1f)
        p.x = p.x.coerceIn(0f, maxOf(0f, 1f - p.w))
        if (p.kind == "address") rebuildParts() else layer.requestLayout()
        updateWebInsets()
        store.save(parts)
        updatePanel()
    }

    // ---------- 第4段階・前半：文字スタイル・バー ----------

    private fun loadTypeface(name: String): Typeface? {
        return try {
            Typeface.createFromFile(File(store.fontDir, name))
        } catch (e: Exception) {
            null
        }
    }

    private fun applyTextStyle(tv: TextView, p: UiPart, defaultSp: Float) {
        tv.textSize = if (p.textSize > 0f) p.textSize else defaultSp
        if (p.textColor != 0) tv.setTextColor(p.textColor)
        typeface?.let { tv.typeface = it }
    }

    private fun applyOverlayStyle(iv: ShapedImageView, p: UiPart) {
        val sp = if (p.textSize > 0f) p.textSize else 14f
        val px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, activity.resources.displayMetrics)
        iv.setOverlayStyle(if (p.textColor != 0) p.textColor else Color.WHITE, px, typeface)
    }

    /** 「タブ数」パーツに、今のタブの数を表示する。 */
    private fun updateTabCounts() {
        val n = core.tabs.size.toString()
        for (p in parts) {
            if (p.action != PartAction.TAB_COUNT.name) continue
            val v = views[p.id]
            if (v is Button) {
                v.text = n
            } else if (v is ShapedImageView) {
                v.setOverlayText(n)
            }
        }
    }

    /** 「ページを避ける」がONのバーの分だけ、Webページの表示範囲を狭める。 */
    private fun updateWebInsets() {
        val lw = layer.width
        val lh = layer.height
        if (lw <= 0 || lh <= 0) return
        var top = 0
        var bottom = 0
        for (p in parts) {
            if (p.kind != "bar" || !p.pushPage) continue
            val ph = (p.w * lw * p.aspect).toInt().coerceIn(1, lh)
            val py = (p.y * lh).toInt().coerceIn(0, maxOf(0, lh - ph))
            if (py + ph / 2 < lh / 2) {
                top = maxOf(top, py + ph)
            } else {
                bottom = maxOf(bottom, lh - py)
            }
        }
        if (top != lastInsetTop || bottom != lastInsetBottom) {
            lastInsetTop = top
            lastInsetBottom = bottom
            val lp = webContainer.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = top
            lp.bottomMargin = bottom
            webContainer.layoutParams = lp
        }
    }

    private fun commit(p: UiPart) {
        store.save(parts)
        rebuildParts()
        select(p)
    }

    /** バー・アドレス欄・文字だけのボタンの高さを変える（画像のパーツは縦横比が固定）。 */
    private fun heightPart(factor: Float) {
        val p = selectedPart()
        if (p == null) {
            toast("パーツを選んでください")
            return
        }
        if (p.kind != "bar" && p.imageFile != null) {
            toast("画像のパーツは縦横比が固定です")
            return
        }
        p.aspect = (p.aspect * factor).coerceIn(0.03f, 2f)
        p.baseAspect = p.aspect
        layer.requestLayout()
        store.save(parts)
        updateWebInsets()
        updatePanel()
    }

    /** 「詳細」：選んだパーツの種類に合わせて、色・文字・フォントの設定を出す。 */
    private fun showDetailMenu() {
        val p = selectedPart()
        val items = mutableListOf<String>()
        val acts = mutableListOf<() -> Unit>()
        if (p != null && p.kind == "bar") {
            items.add("バーの色")
            acts.add { showColorDialog("バーの色", false) { c -> p.barColor = c; commit(p) } }
            items.add(if (p.pushPage) "ページを避ける：ON（タップで切替）" else "ページを避ける：OFF（タップで切替）")
            acts.add { p.pushPage = !p.pushPage; commit(p) }
        }
        if (p != null && p.kind != "bar") {
            items.add("文字の色")
            acts.add { showColorDialog("文字の色", true) { c -> p.textColor = c; commit(p) } }
            items.add("文字のサイズ")
            acts.add { showTextSizeDialog(p) }
        }
        items.add("フォントを選ぶ（全体に適用）")
        acts.add { pickFont() }
        if (store.fontFile != null) {
            items.add("フォントを標準に戻す")
            acts.add { clearFont() }
        }
        AlertDialog.Builder(activity)
            .setTitle("詳細設定")
            .setItems(items.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showColorDialog(title: String, forText: Boolean, onPick: (Int) -> Unit) {
        val names = mutableListOf<String>()
        val values = mutableListOf<Int>()
        if (forText) {
            names.add("標準")
            values.add(0)
        }
        for (i in COLOR_NAMES.indices) {
            if (forText && COLOR_VALUES[i] == 0) continue // 文字色に「透明」は使わない
            names.add(COLOR_NAMES[i])
            values.add(COLOR_VALUES[i])
        }
        names.add("色コードを入力")
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, which ->
                if (which < values.size) onPick(values[which]) else showHexInput(onPick)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showHexInput(onPick: (Int) -> Unit) {
        val input = EditText(activity)
        input.isSingleLine = true
        input.hint = "#RRGGBB（例 #FF8800）"
        AlertDialog.Builder(activity)
            .setTitle("色コード")
            .setView(input)
            .setPositiveButton("決定") { _, _ ->
                try {
                    onPick(Color.parseColor(input.text.toString().trim()))
                } catch (e: Exception) {
                    toast("色コードが正しくありません")
                }
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showTextSizeDialog(p: UiPart) {
        val labels = arrayOf("標準", "小さい（10）", "12", "14", "16", "18", "大きい（22）", "特大（28）")
        val values = floatArrayOf(0f, 10f, 12f, 14f, 16f, 18f, 22f, 28f)
        AlertDialog.Builder(activity)
            .setTitle("文字のサイズ")
            .setItems(labels) { _, which ->
                p.textSize = values[which]
                commit(p)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun pickFont() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "*/*"
        @Suppress("DEPRECATION")
        activity.startActivityForResult(intent, REQ_FONT)
    }

    /** フォントファイルが選ばれたあと、MainActivity から呼ばれる。 */
    fun onFontPicked(uri: Uri) {
        val name = store.importFont(uri)
        if (name == null) {
            toast("フォントを読み込めませんでした（.ttf / .otf を選んでください）")
            return
        }
        val old = store.fontFile
        store.fontFile = name
        if (old != null) File(store.fontDir, old).delete()
        store.save(parts)
        rebuildParts()
    }

    private fun clearFont() {
        val old = store.fontFile ?: return
        store.fontFile = null
        File(store.fontDir, old).delete()
        store.save(parts)
        rebuildParts()
    }

    private fun confirmReset() {
        AlertDialog.Builder(activity)
            .setTitle("初期状態に戻す")
            .setMessage("ボタンの配置・サイズ・画像・フォントをすべて初期状態に戻します。")
            .setPositiveButton("戻す") { _, _ ->
                val oldImages = parts.flatMap { listOfNotNull(it.imageFile, it.pressedFile) }
                parts = store.defaultLayout()
                store.fontFile?.let { File(store.fontDir, it).delete() }
                store.fontFile = null
                selectedId = null
                store.save(parts)
                for (n in oldImages) File(store.imageDir, n).delete()
                rebuildParts()
                updatePanel()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }
}
