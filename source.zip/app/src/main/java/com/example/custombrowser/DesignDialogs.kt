package com.example.custombrowser

// ============================================================
// 「デザインの管理」の画面（切り替え・新規・複製・名前変更・バックアップ・復元・削除）
// ============================================================

import android.app.Activity
import android.app.AlertDialog
import android.widget.EditText
import android.widget.Toast

class DesignDialogs(
    private val activity: Activity,
    private val mgr: DesignManager,
    private val saveCurrent: () -> Unit,
    private val switchTo: (String) -> Unit,
    private val requestExport: (List<String>, String) -> Unit,
    private val requestImport: () -> Unit
) {

    private fun toast(msg: String) {
        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
    }

    fun show() {
        val designs = mgr.list()
        val active = mgr.activeId()
        val labels = mutableListOf("＋ 新しいデザインを作る（初期配置）", "ZIPから復元", "すべてのデザインをバックアップ")
        for (d in designs) {
            labels.add((if (d.id == active) "● " else "") + d.name)
        }
        AlertDialog.Builder(activity)
            .setTitle("デザインの管理（● が使用中）")
            .setItems(labels.toTypedArray()) { _, which ->
                when (which) {
                    0 -> askName("新しいデザインの名前", "新しいデザイン") { name ->
                        saveCurrent()
                        switchTo(mgr.create(name))
                    }
                    1 -> requestImport()
                    2 -> {
                        saveCurrent()
                        requestExport(designs.map { it.id }, "browser-designs-all.zip")
                    }
                    else -> showDesign(designs[which - 3])
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showDesign(d: DesignInfo) {
        val isActive = d.id == mgr.activeId()
        val items = arrayOf(
            if (isActive) "（現在使用中）" else "このデザインに切り替える",
            "名前を変更",
            "複製",
            "バックアップ（ZIPで保存）",
            "削除"
        )
        AlertDialog.Builder(activity)
            .setTitle(d.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> if (!isActive) {
                        saveCurrent()
                        switchTo(d.id)
                    }
                    1 -> askName("名前の変更", d.name) { name ->
                        mgr.rename(d.id, name)
                        show()
                    }
                    2 -> {
                        saveCurrent()
                        if (mgr.duplicate(d.id) != null) toast("複製しました") else toast("複製できませんでした")
                        show()
                    }
                    3 -> {
                        saveCurrent()
                        requestExport(listOf(d.id), safeFileName(d.name) + ".zip")
                    }
                    else -> confirmDelete(d)
                }
            }
            .setNegativeButton("戻る") { _, _ -> show() }
            .show()
    }

    private fun confirmDelete(d: DesignInfo) {
        if (d.id == mgr.activeId()) {
            toast("使用中のデザインは削除できません。先に別のデザインへ切り替えてください")
            return
        }
        if (mgr.list().size <= 1) {
            toast("最後の1つは削除できません")
            return
        }
        AlertDialog.Builder(activity)
            .setTitle("「" + d.name + "」を削除")
            .setMessage("このデザインの配置・画像・フォントを削除します。元に戻せません（バックアップがあれば復元できます）。")
            .setPositiveButton("削除") { _, _ ->
                if (mgr.delete(d.id)) toast("削除しました") else toast("削除できませんでした")
                show()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(activity)
        input.isSingleLine = true
        input.setText(initial)
        input.setSelection(initial.length)
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("決定") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) toast("名前を入力してください") else onOk(name.take(40))
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    /** ファイル名に使えない文字を「_」にする。 */
    private fun safeFileName(name: String): String {
        val bad = "\\/:*?\"<>|"
        return name.map { c -> if (bad.indexOf(c) >= 0) '_' else c }.joinToString("")
    }
}
