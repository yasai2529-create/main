package com.example.custombrowser

// ============================================================
// 画像ボタン用の部品。
// ・透明な部分はタップに反応しない（反応しなかったタップは、下にあるパーツやWebページに届く）
// ・押している間は「押したときの画像」に切り替わる
// 判定用に、画像を小さな「型（マスク）」に縮小して使うので、軽く動きます。
// ============================================================

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.os.Build
import java.io.File
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.widget.ImageView

class ShapedImageView(context: Context) : ImageView(context) {

    private var normal: Bitmap? = null
    private var pressedBmp: Bitmap? = null
    private var mask: BooleanArray? = null
    private var maskW = 0
    private var maskH = 0
    private var overlayText: String? = null
    private var animated: Drawable? = null // GIFなどの動く画像（なければ null）
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    init {
        scaleType = ScaleType.FIT_XY
    }

    /** 画像の上に文字（タブの数など）を重ねて表示するための設定。 */
    fun setOverlayStyle(color: Int, sizePx: Float, tf: Typeface?) {
        textPaint.color = color
        textPaint.textSize = sizePx
        if (tf != null) textPaint.typeface = tf
        invalidate()
    }

    fun setOverlayText(text: String?) {
        overlayText = text
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = overlayText ?: return
        val y = height / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        canvas.drawText(t, width / 2f, y, textPaint)
    }

    /** 動く画像（GIF）を表示する。タップ判定は、最初のコマの形で行う。 */
    fun setAnimatedDrawable(d: Drawable) {
        animated = d
        setImageDrawable(d)
        startAnimation()
    }

    private fun startAnimation() {
        (animated as? Animatable)?.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startAnimation()
    }

    override fun onDetachedFromWindow() {
        (animated as? Animatable)?.stop()
        super.onDetachedFromWindow()
    }

    fun setImages(normalBitmap: Bitmap, pressedBitmap: Bitmap?) {
        normal = normalBitmap
        pressedBmp = pressedBitmap
        setImageBitmap(normalBitmap)
        buildMask(normalBitmap)
    }

    /** 画像を最大96px程度に縮小し、「不透明な場所」を記録する。 */
    private fun buildMask(bmp: Bitmap) {
        val longSide = maxOf(bmp.width, bmp.height)
        val scale = if (longSide > 96) 96f / longSide else 1f
        val mw = maxOf(1, (bmp.width * scale).toInt())
        val mh = maxOf(1, (bmp.height * scale).toInt())
        val small = Bitmap.createScaledBitmap(bmp, mw, mh, true)
        val px = IntArray(mw * mh)
        small.getPixels(px, 0, mw, 0, 0, mw, mh)
        val m = BooleanArray(mw * mh)
        var any = false
        for (i in px.indices) {
            val alpha = px[i] ushr 24
            if (alpha > 24) {
                m[i] = true
                any = true
            }
        }
        if (small !== bmp) small.recycle()
        if (any) {
            mask = m
            maskW = mw
            maskH = mh
        } else {
            mask = null // 完全に透明な画像は、四角形で判定する
        }
    }

    /** タップ位置が不透明な部分か。指で押しやすいよう、周囲1マスぶん余裕を持たせる。 */
    private fun hit(x: Float, y: Float): Boolean {
        val m = mask ?: return true
        if (width <= 0 || height <= 0) return true
        val cx = (x / width * maskW).toInt().coerceIn(0, maskW - 1)
        val cy = (y / height * maskH).toInt().coerceIn(0, maskH - 1)
        for (dy in -1..1) {
            for (dx in -1..1) {
                val ix = cx + dx
                val iy = cy + dy
                if (ix in 0 until maskW && iy in 0 until maskH && m[iy * maskW + ix]) return true
            }
        }
        return false
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN && !hit(event.x, event.y)) {
            return false
        }
        return super.dispatchTouchEvent(event)
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val n = normal ?: return
        val p = pressedBmp
        val a = animated
        if (pressed && p != null) {
            setImageBitmap(p)
        } else if (a != null) {
            setImageDrawable(a)
            startAnimation()
        } else {
            setImageBitmap(n)
        }
    }
}

/** GIF（動く画像）を読み込む。Android 9（API 28）以上で動く。それ未満や失敗時は null（静止画で表示）。 */
object GifSupport {
    fun load(file: File): Drawable? {
        if (Build.VERSION.SDK_INT < 28 || !file.exists()) return null
        return try {
            val src = ImageDecoder.createSource(file)
            val d = ImageDecoder.decodeDrawable(src) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val longSide = maxOf(w, h)
                if (longSide > 768) {
                    val s = 768f / longSide
                    decoder.setTargetSize(maxOf(1, (w * s).toInt()), maxOf(1, (h * s).toInt()))
                }
            }
            if (d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                d
            } else {
                null
            }
        } catch (e: Throwable) {
            null
        }
    }
}
