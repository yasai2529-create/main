package com.example.custombrowser

// ============================================================
// ページ内検索バー（Chromeのような、画面の上に出る検索欄）
// ・ダイアログではないので、画面が暗くならず、ページもスクロールできる
// ・入力するたびに検索され、「3/12」のように件数が出る
// ・▲▼で前後の一致へ移動、✕で閉じる
// ============================================================

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class FindBar(
    private val activity: Activity,
    private val core: BrowserCore,
    private val onVisibilityChanged: () -> Unit
) {

    val view = LinearLayout(activity)
    val heightPx: Int
    var visible = false
        private set

    private val input = EditText(activity)
    private val count = TextView(activity)
    private val buttons = mutableListOf<TextView>()

    init {
        val dm = activity.resources.displayMetrics
        heightPx = (56 * dm.density).toInt()

        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.setBackgroundColor(0xFF202124.toInt())
        view.isClickable = true // 下のページを触ってしまわないよう、タップを受け止める
        view.visibility = View.GONE
        view.setPadding((12 * dm.density).toInt(), 0, 0, 0)

        input.isSingleLine = true
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.hint = "ページ内を検索"
        input.setHintTextColor(Color.GRAY)
        input.setTextColor(Color.WHITE)
        input.textSize = 16f
        input.background = null
        input.setOnEditorActionListener { _, _, _ ->
            core.findNext(true)
            true
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                search(s?.toString() ?: "")
            }
        })
        view.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        count.setTextColor(Color.LTGRAY)
        count.textSize = 14f
        count.setPadding(0, 0, (8 * dm.density).toInt(), 0)
        view.addView(
            count,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val btnW = (48 * dm.density).toInt()
        view.addView(iconButton("▲") { core.findNext(false) }, LinearLayout.LayoutParams(btnW, ViewGroup.LayoutParams.MATCH_PARENT))
        view.addView(iconButton("▼") { core.findNext(true) }, LinearLayout.LayoutParams(btnW, ViewGroup.LayoutParams.MATCH_PARENT))
        view.addView(iconButton("✕") { hide() }, LinearLayout.LayoutParams(btnW, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun iconButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(activity)
        t.text = label
        t.textSize = 18f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        buttons.add(t)
        return t
    }

    private fun search(q: String) {
        val wv = core.currentTab?.webView ?: return
        if (q.isEmpty()) {
            wv.clearMatches()
            count.text = ""
            return
        }
        wv.setFindListener { active, total, _ ->
            count.text = if (total == 0) "0/0" else (active + 1).toString() + "/" + total
        }
        core.find(q)
    }

    /** 色を反映する（0 は標準の色）。 */
    fun applyColors(bg: Int, text: Int, button: Int) {
        view.setBackgroundColor(if (bg != 0) bg else 0xFF202124.toInt())
        val t = if (text != 0) text else Color.WHITE
        input.setTextColor(t)
        input.setHintTextColor(if (text != 0) ((t and 0x00FFFFFF) or 0x99000000.toInt()) else Color.GRAY)
        count.setTextColor(if (text != 0) t else Color.LTGRAY)
        val b = if (button != 0) button else Color.WHITE
        for (x in buttons) x.setTextColor(b)
    }

    /** focus=false のときは、キーボードを出さずに表示だけする（色の確認用）。 */
    fun show(focus: Boolean = true) {
        visible = true
        view.visibility = View.VISIBLE
        if (focus) {
            input.requestFocus()
            input.post {
                val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }
        }
        onVisibilityChanged()
    }

    fun hide() {
        if (!visible) return
        visible = false
        core.clearFind()
        core.currentTab?.webView?.setFindListener(null)
        input.setText("")
        count.text = ""
        val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
        view.visibility = View.GONE
        onVisibilityChanged()
    }
}
