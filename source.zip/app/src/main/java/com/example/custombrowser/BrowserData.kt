package com.example.custombrowser

// ============================================================
// ブックマーク・履歴・設定の保存場所。
// どれも、アプリ専用の領域に保存されます（アプリを消さない限り残ります）。
// ============================================================

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Entry(val title: String, val url: String, val time: Long)

class BrowserData(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val bookmarkFile = File(context.filesDir, "bookmarks.json")
    private val historyFile = File(context.filesDir, "history.json")

    /** プライベートブラウジング中か（アプリを閉じると OFF に戻る） */
    var privateMode = false

    var homeUrl: String
        get() = prefs.getString("homeUrl", HOME_URL) ?: HOME_URL
        set(v) {
            prefs.edit().putString("homeUrl", v).apply()
        }

    /** 文字サイズ（%）。100が標準 */
    var textZoom: Int
        get() = prefs.getInt("textZoom", 100)
        set(v) {
            prefs.edit().putInt("textZoom", v).apply()
        }

    val bookmarks: MutableList<Entry> = readList(bookmarkFile)
    val history: MutableList<Entry> = readList(historyFile)

    private fun readList(file: File): MutableList<Entry> {
        val list = mutableListOf<Entry>()
        try {
            if (file.exists()) {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(Entry(o.getString("t"), o.getString("u"), o.optLong("time", 0L)))
                }
            }
        } catch (e: Exception) {
            // 読めなければ空のまま
        }
        return list
    }

    private fun writeList(file: File, list: List<Entry>) {
        try {
            val arr = JSONArray()
            for (e in list) {
                val o = JSONObject()
                o.put("t", e.title)
                o.put("u", e.url)
                o.put("time", e.time)
                arr.put(o)
            }
            val tmp = File(file.path + ".tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(file)
        } catch (e: Exception) {
            // 保存に失敗しても、アプリは止めない
        }
    }

    fun addBookmark(title: String, url: String): Boolean {
        if (bookmarks.any { it.url == url }) return false
        bookmarks.add(0, Entry(title, url, System.currentTimeMillis()))
        writeList(bookmarkFile, bookmarks)
        return true
    }

    fun removeBookmark(index: Int) {
        if (index in bookmarks.indices) {
            bookmarks.removeAt(index)
            writeList(bookmarkFile, bookmarks)
        }
    }

    fun addHistory(title: String, url: String) {
        val now = System.currentTimeMillis()
        if (history.firstOrNull()?.url == url) {
            history[0] = Entry(title, url, now)
        } else {
            history.add(0, Entry(title, url, now))
        }
        while (history.size > 300) history.removeAt(history.size - 1)
        writeList(historyFile, history)
    }

    fun removeHistory(index: Int) {
        if (index in history.indices) {
            history.removeAt(index)
            writeList(historyFile, history)
        }
    }

    fun clearHistory() {
        history.clear()
        writeList(historyFile, history)
    }
}
