package com.example.custombrowser

// ============================================================
// ブラウザ本体（機能だけを担当。見た目のことは一切知らない）
// 後の段階で、見た目（BrowserUi）を差し替えても、このファイルは変えません。
// ============================================================

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.URLEncoder

const val HOME_URL = "https://www.google.com"

/** 1つのタブ。WebView が Webページを表示する部品です。 */
class Tab(val id: Int, val webView: WebView) {
    var title: String = "新しいタブ"
    var url: String = ""
}

/** 本体から見た目側への通知窓口。 */
interface BrowserListener {
    /** タブが増減・切り替わった */
    fun onTabChanged()

    /** ページのURLやタイトルが変わった */
    fun onPageInfo(tab: Tab)
}

class BrowserCore(private val context: Context) {

    val tabs = mutableListOf<Tab>()
    var currentIndex = -1
        private set
    var listener: BrowserListener? = null

    private var nextId = 1

    val currentTab: Tab?
        get() = tabs.getOrNull(currentIndex)

    // ---------- タブ操作 ----------

    @SuppressLint("SetJavaScriptEnabled")
    fun newTab(url: String = HOME_URL) {
        val wv = WebView(context)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true

        val tab = Tab(nextId++, wv)

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = if (title.isNullOrBlank()) tab.url else title
                listener?.onPageInfo(tab)
            }
        }

        tabs.add(tab)
        currentIndex = tabs.lastIndex
        wv.loadUrl(url)
        listener?.onTabChanged()
    }

    fun switchTo(index: Int) {
        if (index in tabs.indices) {
            currentIndex = index
            listener?.onTabChanged()
        }
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        tab.webView.destroy()
        if (tabs.isEmpty()) {
            newTab()
            return
        }
        currentIndex = when {
            currentIndex > index -> currentIndex - 1
            currentIndex >= tabs.size -> tabs.lastIndex
            else -> currentIndex
        }
        listener?.onTabChanged()
    }

    fun closeCurrentTab() = closeTab(currentIndex)

    // ---------- ページ操作 ----------

    fun goBack() {
        currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
    }

    fun goForward() {
        currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        currentTab?.webView?.reload()
    }

    fun goHome() {
        currentTab?.webView?.loadUrl(HOME_URL)
    }

    /** URLならそのまま開き、そうでなければ検索する。 */
    fun openInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        currentTab?.webView?.loadUrl(toUrl(text))
    }

    private fun toUrl(text: String): String {
        if (text.startsWith("http://") || text.startsWith("https://")) return text
        if (!text.contains(" ") && text.contains(".")) return "https://$text"
        return "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8")
    }
}
