package com.example.custombrowser

// ============================================================
// ブラウザ本体（機能だけを担当。見た目のことは一切知らない）
// 後の段階で、見た目（BrowserUi）を差し替えても、このファイルは変えません。
// ============================================================

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.URLEncoder

const val HOME_URL = "https://www.google.com"

/** 1つのタブ。WebView が Webページを表示する部品です。 */
class Tab(val id: Int, val webView: WebView) {
    var title: String = "新しいタブ"
    var url: String = ""
    var thumb: Bitmap? = null // タブ一覧用の縮小画像
}

/** 本体から見た目側への通知窓口。 */
interface BrowserListener {
    /** タブが増減・切り替わった */
    fun onTabChanged()

    /** ページのURLやタイトルが変わった */
    fun onPageInfo(tab: Tab)
}

class BrowserCore(private val context: Context) {

    val tabs = mutableListOf<Tab>()
    var currentIndex = -1
        private set
    var listener: BrowserListener? = null

    private var nextId = 1

    val currentTab: Tab?
        get() = tabs.getOrNull(currentIndex)

    // ---------- タブ操作 ----------

    @SuppressLint("SetJavaScriptEnabled")
    fun newTab(url: String = HOME_URL) {
        captureThumb(currentTab)
        val wv = WebView(context)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true

        val tab = Tab(nextId++, wv)

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
                // 読み込み後に少し待ってから、タブ一覧用の縮小画像を撮る
                view?.postDelayed({ if (tab === currentTab) captureThumb(tab) }, 700)
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = if (title.isNullOrBlank()) tab.url else title
                listener?.onPageInfo(tab)
            }
        }

        tabs.add(tab)
        currentIndex = tabs.lastIndex
        wv.loadUrl(url)
        listener?.onTabChanged()
    }

    fun switchTo(index: Int) {
        if (index in tabs.indices) {
            if (index != currentIndex) captureThumb(currentTab)
            currentIndex = index
            listener?.onTabChanged()
        }
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        tab.thumb?.recycle()
        tab.thumb = null
        tab.webView.destroy()
        if (tabs.isEmpty()) {
            newTab()
            return
        }
        currentIndex = when {
            currentIndex > index -> currentIndex - 1
            currentIndex >= tabs.size -> tabs.lastIndex
            else -> currentIndex
        }
        listener?.onTabChanged()
    }

    fun closeCurrentTab() = closeTab(currentIndex)

    /** 表示中のタブを 1/4 サイズの画像にして保存する（タブ一覧のサムネイル用）。 */
    fun captureThumb(tab: Tab?) {
        if (tab == null) return
        val wv = tab.webView
        if (wv.width <= 0 || wv.height <= 0 || !wv.isShown) return
        try {
            val scale = 0.25f
            val w = (wv.width * scale).toInt().coerceAtLeast(1)
            val h = (wv.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.scale(scale, scale)
            wv.draw(canvas)
            tab.thumb?.recycle()
            tab.thumb = bmp
        } catch (e: Throwable) {
            // 撮れなかったら、何もしない（サムネイルなしで表示される）
        }
    }

    // ---------- ページ操作 ----------

    fun goBack() {
        currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
    }

    fun goForward() {
        currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        currentTab?.webView?.reload()
    }

    fun goHome() {
        currentTab?.webView?.loadUrl(HOME_URL)
    }

    /** URLならそのまま開き、そうでなければ検索する。 */
    fun openInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        currentTab?.webView?.loadUrl(toUrl(text))
    }

    private fun toUrl(text: String): String {
        if (text.startsWith("http://") || text.startsWith("https://")) return text
        if (!text.contains(" ") && text.contains(".")) return "https://$text"
        return "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8")
    }
}
