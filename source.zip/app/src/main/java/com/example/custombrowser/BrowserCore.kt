package com.example.custombrowser

// ============================================================
// ブラウザ本体（機能だけを担当。見た目のことは一切知らない）
// 後の段階で、見た目（BrowserUi）を差し替えても、このファイルは変えません。
// ============================================================

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.http.SslError
import android.os.Message
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.URLEncoder

const val HOME_URL = "https://www.google.com"

/** 1つのタブ。WebView が Webページを表示する部品です。 */
class Tab(val id: Int, val webView: WebView) {
    var title: String = "新しいタブ"
    var url: String = ""
    var thumb: Bitmap? = null // タブ一覧用の縮小画像
}

/** 本体から見た目側への通知窓口。 */
interface BrowserListener {
    /** タブが増減・切り替わった */
    fun onTabChanged()

    /** ページのURLやタイトルが変わった */
    fun onPageInfo(tab: Tab)
}

class BrowserCore(private val context: Context) {

    /** ブックマーク・履歴・設定 */
    val data = BrowserData(context)

    val tabs = mutableListOf<Tab>()
    var currentIndex = -1
        private set
    var listener: BrowserListener? = null

    // 画面側（Activity・UI）に頼む処理の窓口
    var fileChooserHandler: ((ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams) -> Boolean)? = null
    var customViewShow: ((View, WebChromeClient.CustomViewCallback) -> Unit)? = null
    var customViewHide: (() -> Unit)? = null

    private var nextId = 1

    val currentTab: Tab?
        get() = tabs.getOrNull(currentIndex)

    // ---------- タブ操作 ----------

    /** load=false は、サイトが開く新しいウィンドウ（ポップアップ）用。中身はサイト側が読み込む。 */
    fun newTab(url: String? = null, load: Boolean = true): WebView {
        captureThumb(currentTab)
        val wv = WebView(context)
        configureWebView(wv)
        // ログインなどで使われる、外部サービスのCookieを受け付ける
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(dlUrl, userAgent, contentDisposition, mimeType)
        }

        val tab = Tab(nextId++, wv)

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.url = url ?: ""
                listener?.onPageInfo(tab)
                if (!data.privateMode && !url.isNullOrBlank() && url != "about:blank") {
                    data.addHistory(view?.title ?: url, url)
                }
                // 読み込み後に少し待ってから、タブ一覧用の縮小画像を撮る
                view?.postDelayed({ if (tab === currentTab) captureThumb(tab) }, 700)
            }

            // mailto: / tel: / アプリ用のリンク（intent: など）を、対応するアプリで開く
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (request == null) return false
                return handleSpecialUrl(view, request.url.toString(), request.hasGesture())
            }

            // 読み込みに失敗したら、白い画面のままにせず、理由を表示する
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame) {
                    showErrorPage(view, request.url.toString(), describeError(error?.description?.toString() ?: ""))
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel() // 証明書に問題があるサイトは、安全のため開かない
                showErrorPage(view, error?.url ?: "", "このサイトの証明書に問題があるため、安全のために接続を中止しました。")
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = if (title.isNullOrBlank()) tab.url else title
                listener?.onPageInfo(tab)
            }

            // リンクを押して「新しいウィンドウ」で開くサイト（ログイン画面など）を、新しいタブで開く
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                if (resultMsg == null || !isUserGesture) return false // 自動で開く広告ウィンドウなどは開かない
                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                transport.webView = newTab(null, false)
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                val i = tabs.indexOfFirst { it.webView === window }
                if (i >= 0) closeTab(i)
            }

            // 画像・ファイルのアップロード
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                val h = fileChooserHandler ?: return false
                return h(filePathCallback, fileChooserParams)
            }

            // 動画の全画面表示
            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null || callback == null) return
                customViewShow?.invoke(view, callback)
            }

            override fun onHideCustomView() {
                customViewHide?.invoke()
            }
        }

        tabs.add(tab)
        currentIndex = tabs.lastIndex
        if (load) wv.loadUrl(url ?: data.homeUrl)
        listener?.onTabChanged()
        return wv
    }

    fun switchTo(index: Int) {
        if (index in tabs.indices) {
            if (index != currentIndex) captureThumb(currentTab)
            currentIndex = index
            listener?.onTabChanged()
        }
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        tab.thumb?.recycle()
        tab.thumb = null
        tab.webView.destroy()
        if (tabs.isEmpty()) {
            newTab()
            return
        }
        currentIndex = when {
            currentIndex > index -> currentIndex - 1
            currentIndex >= tabs.size -> tabs.lastIndex
            else -> currentIndex
        }
        listener?.onTabChanged()
    }

    fun closeCurrentTab() = closeTab(currentIndex)

    /** 表示中のタブを 1/4 サイズの画像にして保存する（タブ一覧のサムネイル用）。 */
    fun captureThumb(tab: Tab?) {
        if (tab == null) return
        val wv = tab.webView
        if (wv.width <= 0 || wv.height <= 0 || !wv.isShown) return
        try {
            val scale = 0.25f
            val w = (wv.width * scale).toInt().coerceAtLeast(1)
            val h = (wv.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.scale(scale, scale)
            wv.draw(canvas)
            tab.thumb?.recycle()
            tab.thumb = bmp
        } catch (e: Throwable) {
            // 撮れなかったら、何もしない（サムネイルなしで表示される）
        }
    }

    // ---------- 設定・ダウンロード・検索 ----------

    fun loadUrl(url: String) {
        currentTab?.webView?.loadUrl(url)
    }

    /** 文字サイズ・プライベート中のキャッシュ設定を、開いているすべてのタブに反映する。 */
    fun applySettings() {
        for (t in tabs) configureWebView(t.webView)
    }

    private var defaultUserAgent: String? = null

    /**
     * WebViewの設定。多くのサイトを開けるように、ブラウザらしい設定にそろえる。
     * ・ポップアップ（新しいウィンドウ）対応／ピンチでの拡大縮小／http・https混在のページ
     * ・ブラウザの名乗り（ユーザーエージェント）を、普通のスマホChromeに近づける（「WebView」とバレにくくする）
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.textZoom = data.textZoom
        s.cacheMode = if (data.privateMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false

        if (defaultUserAgent == null) defaultUserAgent = s.userAgentString
        val base = defaultUserAgent ?: s.userAgentString
        s.userAgentString = if (data.desktopMode) {
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        } else {
            base.replace("; wv", "").replace("Version/4.0 ", "")
        }
    }

    /**
     * http/https 以外のリンク（mailto:, tel:, line:, intent: など）を、対応するアプリで開く。
     * 押していないのに自動で呼ばれたものは、無視する。開く必要がなければ false を返す。
     */
    private fun handleSpecialUrl(view: WebView?, url: String, hasGesture: Boolean): Boolean {
        val lower = url.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("about:") ||
            lower.startsWith("javascript:") || lower.startsWith("data:") || lower.startsWith("blob:") ||
            lower.startsWith("file:")
        ) {
            return false
        }
        if (!hasGesture) return true
        try {
            val intent = if (lower.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null // サイトに、特定のアプリの内部を直接呼ばせない
            intent.selector = null
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            var opened = false
            if (lower.startsWith("intent:")) {
                try {
                    val fallback = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url")
                    if (fallback != null && fallback.startsWith("http")) {
                        view?.loadUrl(fallback)
                        opened = true
                    }
                } catch (e2: Exception) {
                    // フォールバック先も使えなかった
                }
            }
            if (!opened) Toast.makeText(context, "このリンクを開けるアプリがありません", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    private fun describeError(desc: String): String {
        return when {
            desc.contains("ERR_NAME_NOT_RESOLVED") -> "サイトのアドレスが見つかりません（アドレスの間違いか、通信できていません）。"
            desc.contains("ERR_INTERNET_DISCONNECTED") -> "インターネットに接続されていません。"
            desc.contains("ERR_CONNECTION_TIMED_OUT") || desc.contains("ERR_TIMED_OUT") -> "接続がタイムアウトしました。通信状況を確認してください。"
            desc.contains("ERR_CONNECTION_REFUSED") || desc.contains("ERR_CONNECTION_RESET") -> "サイトに接続できませんでした。"
            desc.contains("ERR_UNKNOWN_URL_SCHEME") -> "このアドレスの種類には対応していません。"
            desc.contains("ERR_CLEARTEXT") -> "暗号化されていない通信（http）が許可されていません。"
            desc.isBlank() -> "原因を特定できませんでした。"
            else -> "エラー：" + desc
        }
    }

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun showErrorPage(view: WebView?, url: String, message: String) {
        if (view == null) return
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
            "<body style='font-family:sans-serif;padding:24px;background:#fafafa;color:#222'>" +
            "<h2>ページを開けませんでした</h2><p>" + esc(message) + "</p>" +
            "<p style='color:#666;word-break:break-all'>" + esc(url) + "</p>" +
            "<p><a href=\"" + esc(url) + "\">もう一度読み込む</a></p>" +
            "<p style='color:#666;font-size:14px'>よくある原因：通信が不安定／アドレスの入力間違い／" +
            "そのサイトがアプリ内ブラウザ（WebView）をブロックしている（その場合は、設定の「PCサイトで表示」を試せます）</p>" +
            "</body></html>"
        view.loadDataWithBaseURL(url, html, "text/html", "UTF-8", url)
    }

    /**
     * プライベートブラウジングの切り替え。
     * 履歴を残さず、キャッシュも使わない。OFFに戻すときはキャッシュを消す。
     * ※Cookieはタブごとに分けられないため、そのまま共通で使われる（消すと、普段のログインも外れてしまうため）。
     */
    fun setPrivate(on: Boolean) {
        data.privateMode = on
        applySettings()
        if (!on) clearCache()
    }

    fun clearCookies() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
    }

    fun clearCache() {
        for (t in tabs) {
            t.webView.clearCache(true)
            t.webView.clearFormData()
        }
    }

    fun find(query: String) {
        currentTab?.webView?.findAllAsync(query)
    }

    fun findNext(forward: Boolean) {
        currentTab?.webView?.findNext(forward)
    }

    fun clearFind() {
        currentTab?.webView?.clearMatches()
    }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
            if (!mimeType.isNullOrBlank()) req.setMimeType(mimeType)
            val cookie = CookieManager.getInstance().getCookie(url)
            if (cookie != null) req.addRequestHeader("Cookie", cookie)
            if (userAgent != null) req.addRequestHeader("User-Agent", userAgent)
            val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            Toast.makeText(context, "ダウンロードを開始しました：" + name, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "ダウンロードできませんでした", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- ページ操作 ----------

    fun goBack() {
        currentTab?.webView?.let { if (it.canGoBack()) it.goBack() }
    }

    fun goForward() {
        currentTab?.webView?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        currentTab?.webView?.reload()
    }

    fun goHome() {
        currentTab?.webView?.loadUrl(data.homeUrl)
    }

    /** URLならそのまま開き、そうでなければ検索する。 */
    fun openInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        currentTab?.webView?.loadUrl(toUrl(text))
    }

    private fun toUrl(text: String): String {
        if (text.startsWith("http://") || text.startsWith("https://")) return text
        if (!text.contains(" ") && text.contains(".")) return "https://$text"
        return "https://www.google.com/search?q=" + URLEncoder.encode(text, "UTF-8")
    }
}
